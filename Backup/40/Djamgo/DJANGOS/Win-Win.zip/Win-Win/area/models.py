from django.db import models


class Area(models.Model):
    name = models.CharField(
        max_length=100, 
        unique=True, 
        verbose_name="Area Name")
    priority = models.PositiveIntegerField(
        null=True, 
        blank=True,
        verbose_name='Priority')
    active_status = models.BooleanField(
        default=1, 
        null=True, 
        blank=True, 
        verbose_name="Area Active Status"
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        editable=False,
        null=True,
        blank=True,
        verbose_name="Creation Date & Time",
    )
    updated_at = models.DateTimeField(
        auto_now=True, 
        null=True, 
        blank=True, 
        verbose_name="Updation Date & Time"
    )

    class Meta:
        verbose_name = "Area"
        verbose_name_plural = "Areas"

    def __str__(self):
        return self.name


class State(models.Model):
    name = models.CharField(
        max_length=100, 
        unique=True, 
        verbose_name="State Name")

    area = models.ForeignKey(
        Area,
        related_name='State_state',
        on_delete=models.CASCADE,
        null=True,
        verbose_name='Area',
        limit_choices_to={'active_status': '1'})

    active_status = models.BooleanField(
        default=1, 
        null=True, 
        blank=True, 
        verbose_name="State Active Status"
    )

    created_at = models.DateTimeField(
        auto_now_add=True,
        editable=False,
        null=True,
        blank=True,
        verbose_name="Creation Date & Time",
    )
    updated_at = models.DateTimeField(
        auto_now=True, 
        null=True, 
        blank=True, 
        verbose_name="Updation Date & Time"
    )

    class Meta:
        verbose_name = "State"
        verbose_name_plural = "State"

    def __str__(self):
        return self.name


class City(models.Model):
    name = models.CharField(
        max_length=100, 
        unique=True, 
        verbose_name="City Name")

    state = models.ForeignKey(
        State,
        related_name='City_city',
        on_delete=models.CASCADE,
        null=True,
        verbose_name='State',
        limit_choices_to={'active_status': '1'})

    active_status = models.BooleanField(
        default=1, 
        null=True, 
        blank=True, 
        verbose_name="Area Active Status"
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        editable=False,
        null=True,
        blank=True,
        verbose_name="Creation Date & Time",
    )
    updated_at = models.DateTimeField(
        auto_now=True, 
        null=True, 
        blank=True, 
        verbose_name="Updation Date & Time"
    )

    class Meta:
        verbose_name = "City"
        verbose_name_plural = "City"

    def __str__(self):
        return self.name