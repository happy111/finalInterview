from django.shortcuts import render
from .models import Area,State,City
from .serializers import AreaSerializer
from rest_framework.generics import (
    CreateAPIView,
    ListAPIView,
    DestroyAPIView,
    UpdateAPIView,
)
from rest_framework.permissions import IsAuthenticated

# from userrole.permissions import IsSuperAdmin, IsAdmin
from rest_framework.response import Response
from rest_framework.status import HTTP_200_OK, HTTP_406_NOT_ACCEPTABLE






class ActiveAreaStateCity(ListAPIView):
    """
    All Area/State/City Listing GET API

        Service Usage and Description : This API is used to list all Area/State/City.
        Authentication Required : YES

        Params : {
     
        }

        Response : {
            "data" : final_data
        }
    """

    permission_classes = (IsAuthenticated,)
    serializer_class = AreaSerializer
    def get_queryset(self):
        queryset = Area.objects.filter(active_status=1).order_by('priority')
        return queryset
    def get(self, request):
        try:
            queryset = self.get_queryset()
            final_data = []
            for index in queryset:
                area_dict = {}
                area_dict['area_id']   = index.id
                area_dict['area'] = index.name
                state_data = State.objects.filter(active_status=1,area_id=index.id)
                if state_data.count() > 0:
                    area_dict['state'] = []
                    for s in state_data:
                        state = {}
                        state['state_id'] = s.id
                        state['name'] = s.name
                        area_dict['state'].append(state)
                        city_data = City.objects.filter(active_status=1,state_id=s.id)
                        if city_data.count() > 0:
                            state['city'] = []
                            for c in city_data:
                                city = {}
                                city['city_id'] = c.id
                                city['name'] = c.name
                                state['city'].append(city)
                        else:
                            pass
                else:
                    pass
                final_data.append(area_dict)
            return Response(final_data, status=HTTP_200_OK)
        except Exception as e:
            return Response(
                {"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
            )






















class AreaCreation(CreateAPIView):
    """
    Area Creation POST API

    	Service Usage and Description : This API is used to create Area.
	    Authentication Required : YES

	    Data : {
	        "name" : "XYZ"
	    }

	    Response : {
	        "data" : final_data
	    }
    """

    # permission_classes = (IsAuthenticated, IsSuperAdmin | IsAdmin)
    serializer_class = AreaSerializer


class ActiveAreaListing(ListAPIView):
    """
    Active Area Listing GET API

	    Service Usage and Description : This API is used to list active areas.
	    Authentication Required : YES

	    Response : {
	        "data" : final_data
	    }
    """

    # permission_classes = (IsAuthenticated,)
    serializer_class = AreaSerializer
    def get_queryset(self):
        queryset = Area.objects.filter(active_status=True)
        return queryset


class AllAreaListing(ListAPIView):
    """
    All Area Listing GET API

	    Service Usage and Description : This API is used to list all areas.
	    Authentication Required : YES

	    Response : {
	        "data" : final_data
	    }
    """

    # permission_classes = (IsAuthenticated,)
    serializer_class = AreaSerializer

    def get_queryset(self):
        queryset = Area.objects.all()
        return queryset


class AreaUpdation(UpdateAPIView):
    """
    Area Updation PUT API

	    Service Usage and Description : This API is used to update Area.
	    Authentication Required : YES

	    Data : {
	        "id" : "1",
	        "name": "ABC"
	    }

	    Response : {
	        "success": True,
	        "message": "Area Updated."
	    }
    """

    # permission_classes = (IsAuthenticated, IsSuperAdmin | IsAdmin)
    serializer_class = AreaSerializer

    def put(self, request):
        try:
            data = request.data
            area = Area.objects.filter(id=data["id"])
            if area.count() == 0:
                raise Exception("No Area with given id.")
            serializer = AreaSerializer(area[0], data=data, partial=True)
            if serializer.is_valid(raise_exception=True):
                serializer.save()
                return Response(
                    {"success": True, "message": "Area Updated."}, status=HTTP_200_OK,
                )
        except Exception as e:
            return Response(
                {"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
            )


class AreaDeletion(DestroyAPIView):
    """
    Area Deletion DELETE API

	    Service Usage and Description : This API is used to delete Area.
	    Authentication Required : YES

	    Data : {
	        "id" : "1"
	    }
	    
	    Response : {
            "success": True,
            "message": "Area Deleted."
        }
    """

    # permission_classes = (IsAuthenticated, IsSuperAdmin | IsAdmin)
    serializer_class = AreaSerializer

    def get_queryset(self):
        area_id = self.request.data["id"]
        queryset = Area.objects.filter(id=area_id)
        return queryset

    def delete(self, request):
        try:
            area = self.get_queryset()
            if area.count() == 0:
                raise Exception("No Area with given id.")
            self.perform_destroy(area)
            return Response(
                {"success": True, "message": "Area Deleted."}, status=HTTP_200_OK,
            )
        except Exception as e:
            return Response(
                {"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
            )
