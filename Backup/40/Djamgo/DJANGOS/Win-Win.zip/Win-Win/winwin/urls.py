"""winwin URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from drf_yasg.views import get_schema_view
from drf_yasg import openapi
from django.conf.urls.static import static
from winwin import settings
from socialfrontend import views

# from django.contrib.auth import views as auth_views

schema_view = get_schema_view(
    openapi.Info(title="Win-Win Backend API DOCumentation", default_version="v1"), public=True,
)

urlpatterns = [
    path("", admin.site.urls),
    path("jet/", include("jet.urls", "jet")),
    path("jet/dashboard/", include("jet.dashboard.urls", "jet-dashboard")),
    path(
        "apidocs/",
        schema_view.with_ui("swagger", cache_timeout=0),
        name="schema-swagger-ui",
    ),
    path("area/", include("area.urls")),
    path("genre/", include("genre.urls")),
    path("shop/", include("shops.urls")),
    # path("home/", views.home, name="home"),
    # path("twitter/", views.login, name="twitter"),
    path("user/", include("users.urls")),
    path("review/", include("review.urls")),
    path("topic/", include("topic.urls")),
    path("social/", include("socialfeatures.urls")),
    path("notification/", include("Notification.urls")),

    # path("oauth/", include("social_django.urls"), name="social"),
]

urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
urlpatterns += static(settings.STATIC_URL, document_root=settings.STATICFILES_DIRS)
