from django.db import models
from users.models import EndUser
from shops.models import Shop
from topic.models import Topic
from review.models import Review
from phonenumber_field.modelfields import PhoneNumberField


class Follow(models.Model):
    followee = models.ForeignKey(
        EndUser,
        on_delete=models.CASCADE,
        related_name="follow_followee",
        limit_choices_to={"active_status": True, "is_banned": False},
        verbose_name="Followee",
    )
    follower = models.ForeignKey(
        EndUser,
        on_delete=models.CASCADE,
        related_name="follow_follower",
        limit_choices_to={"active_status": True, "is_banned": False},
        verbose_name="Follower",
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        editable=False,
        null=True,
        blank=True,
        verbose_name="Creation Date & Time",
    )

    class Meta:
        verbose_name = "Follow"
        verbose_name_plural = "Follow"

    def __str__(self):
        return self.followee.name + " <- " + self.follower.name


class FavoriteShop(models.Model):
    shop = models.ForeignKey(
        Shop,
        on_delete=models.CASCADE,
        related_name="favorite_shop",
        limit_choices_to={"active_status": True, "is_banned": False},
        verbose_name="Shop",
    )
    enduser = models.ForeignKey(
        EndUser,
        on_delete=models.CASCADE,
        related_name="favoriteshop_enduser",
        limit_choices_to={"active_status": True, "is_banned": False},
        verbose_name="End User",
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        editable=False,
        null=True,
        blank=True,
        verbose_name="Creation Date & Time",
    )

    class Meta:
        verbose_name = "Favorite Shop"
        verbose_name_plural = "Favorite Shops"

    def __str__(self):
        return self.shop.name + ", " + self.enduser.name


class FavoriteTopic(models.Model):
    topic = models.ForeignKey(
        Topic,
        on_delete=models.CASCADE,
        related_name="favorite_topic",
        limit_choices_to={"active_status": True},
        verbose_name="Topic",
    )
    enduser = models.ForeignKey(
        EndUser,
        on_delete=models.CASCADE,
        related_name="favoritetopic_enduser",
        limit_choices_to={"active_status": True, "is_banned": False},
        verbose_name="End User",
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        editable=False,
        null=True,
        blank=True,
        verbose_name="Creation Date & Time",
    )

    class Meta:
        verbose_name = "Favorite Topic"
        verbose_name_plural = "Favorite Topics"

    def __str__(self):
        return self.topic.title + ", " + self.enduser.name


class FavoriteReview(models.Model):
    review = models.ForeignKey(
        Review,
        on_delete=models.CASCADE,
        related_name="favorite_review",
        limit_choices_to={"is_active": True},
        verbose_name="Review",
    )
    enduser = models.ForeignKey(
        EndUser,
        on_delete=models.CASCADE,
        related_name="favoritereview_enduser",
        limit_choices_to={"active_status": True, "is_banned": False},
        verbose_name="End User",
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        editable=False,
        null=True,
        blank=True,
        verbose_name="Creation Date & Time",
    )

    class Meta:
        verbose_name = "Favorite Review"
        verbose_name_plural = "Favorite Review"

    def __str__(self):
        return self.review.content + ", " + self.enduser.name









class ShopViews(models.Model):
    shop = models.ForeignKey(
        Shop,
        on_delete=models.CASCADE,
        related_name="shopviews_shop",
        verbose_name="Shop",
    )
    enduser = models.ForeignKey(
        EndUser,
        on_delete=models.CASCADE,
        related_name="shopviews_enduser",
        verbose_name="End User",
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        editable=False,
        null=True,
        blank=True,
        verbose_name="Creation Date & Time",
    )

    class Meta:
        verbose_name = "Shop View"
        verbose_name_plural = "Shop Views"

    def __str__(self):
        return self.shop.name + ", " + self.enduser.name


class TopicViews(models.Model):
    topic = models.ForeignKey(
        Topic,
        on_delete=models.CASCADE,
        related_name="topicviews_topic",
        verbose_name="Topic",
    )
    enduser = models.ForeignKey(
        EndUser,
        on_delete=models.CASCADE,
        related_name="topicviews_enduser",
        verbose_name="End User",
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        editable=False,
        null=True,
        blank=True,
        verbose_name="Creation Date & Time",
    )

    class Meta:
        verbose_name = "Topic View"
        verbose_name_plural = "Topic Views"

    def __str__(self):
        return self.topic.title + ", " + self.enduser.name





class ProfileView(models.Model):
    enduser = models.ForeignKey(
        EndUser,
        on_delete=models.CASCADE,
        related_name="ProfileView_enduser",
        limit_choices_to={"active_status": True, "is_banned": False},
        verbose_name="EndUser"
    )
    profile = models.ForeignKey(
        EndUser,
        on_delete=models.CASCADE,
        related_name="Profile_profile",
        limit_choices_to={"active_status": True, "is_banned": False},
        verbose_name="Profile",
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        editable=False,
        null=True,
        blank=True,
        verbose_name="Creation Date & Time",
    )

    class Meta:
        verbose_name = "ProfileView"
        verbose_name_plural = "ProfileView"

    def __str__(self):
        return self.enduser.name + " <- " + self.profile.name





class ReviewViews(models.Model):
    review = models.ForeignKey(
        Review,
        on_delete=models.CASCADE,
        related_name="reviewviews_review",
        verbose_name="Review",
    )
    enduser = models.ForeignKey(
        EndUser,
        on_delete=models.CASCADE,
        related_name="reviewviews_enduser",
        verbose_name="End User",
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        editable=False,
        null=True,
        blank=True,
        verbose_name="Creation Date & Time",
    )

    class Meta:
        verbose_name = "Review View"
        verbose_name_plural = "Review Views"

    def __str__(self):
        return self.review.id + ", " + self.enduser.name


class JobApplication(models.Model):
    shop = models.ForeignKey(
        Shop,
        on_delete=models.CASCADE,
        related_name="jobapplication_shop",
        verbose_name="Shop",
    )
    enduser = models.ForeignKey(
        EndUser,
        on_delete=models.CASCADE,
        related_name="jobapplication_enduser",
        verbose_name="End User",
    )
    content = models.CharField(
        max_length=250, null=True, blank=True, verbose_name="Content"
    )
    email = models.EmailField(verbose_name="E-Mail Address of the End User")
    phone_number = models.CharField(
        null=True, blank=True,max_length=15, verbose_name="Phone Number of the End User"
    )
    active_status = models.BooleanField(
        default=1, null=True, blank=True, verbose_name="Active Status"
    )
    is_supported = models.BooleanField(
        default=0, null=True, blank=True, verbose_name="Is Supported"
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        editable=False,
        null=True,
        blank=True,
        verbose_name="Creation Date & Time",
    )

    class Meta:
        verbose_name = "Job Application"
        verbose_name_plural = "Job Applications"

    def __str__(self):
        return self.shop.name + ", " + self.enduser.name
