from rest_framework import serializers
from .models import *
from users.serializers import EndUserNameSerializer
from shops.serializers import ShopNameSerializer
from topic.serializers import TopicNameSerializer


class FollowSerializer(serializers.ModelSerializer):
    class Meta:
        model = Follow
        fields = "__all__"

class FollowDataSerializer(serializers.ModelSerializer):
    followee = EndUserNameSerializer()
    follower = EndUserNameSerializer()
    class Meta:
        model = Follow
        fields = "__all__"

class FavoriteShopSerializer(serializers.ModelSerializer):
    class Meta:
        model = FavoriteShop
        fields = "__all__"

class FavoriteShopDataSerializer(serializers.ModelSerializer):
    shop = ShopNameSerializer()
    enduser = EndUserNameSerializer()
    class Meta:
        model = FavoriteShop
        fields = "__all__"

class FavoriteTopicSerializer(serializers.ModelSerializer):
    class Meta:
        model = FavoriteTopic
        fields = "__all__"

class FavoriteTopicDataSerializer(serializers.ModelSerializer):
    topic = TopicNameSerializer()
    enduser = EndUserNameSerializer()
    class Meta:
        model = FavoriteTopic
        fields = "__all__"

class ShopViewsSerializer(serializers.ModelSerializer):
    class Meta:
        model = ShopViews
        fields = "__all__"


class TopicViewsSerializer(serializers.ModelSerializer):
    class Meta:
        model = TopicViews
        fields = "__all__"


class JobApplicationSerializer(serializers.ModelSerializer):
    class Meta:
        model = JobApplication
        fields = "__all__"

class JobApplicationDataSerializer(serializers.ModelSerializer):
    shop = ShopNameSerializer()
    enduser = EndUserNameSerializer()
    def to_representation(self, instance):
        representation = super(JobApplicationDataSerializer, self).to_representation(instance)
        representation['created_at'] = instance.created_at.strftime("%Y/%m/%d")
        return representation


    class Meta:
        model = JobApplication
        fields = "__all__"

class FavoriteReviewSerializer(serializers.ModelSerializer):
    class Meta:
        model = FavoriteReview
        fields = "__all__"

class ReviewViewSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReviewViews
        fields = "__all__"