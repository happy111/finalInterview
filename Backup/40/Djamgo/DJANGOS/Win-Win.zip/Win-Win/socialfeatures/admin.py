from django.contrib import admin
from .models import *

admin.site.register(Follow)
admin.site.register(FavoriteShop)
admin.site.register(FavoriteTopic)
admin.site.register(ShopViews)
admin.site.register(TopicViews)
admin.site.register(JobApplication)
