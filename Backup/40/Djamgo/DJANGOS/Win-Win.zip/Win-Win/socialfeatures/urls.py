from django.urls import path
from .views import *

urlpatterns = [
    path("follow-create/", FollowCreation.as_view()),
    path("followee-listing/", FolloweeListing.as_view()),
    path("follower-listing/", FollowerListing.as_view()),
    path("follow-count-listing/", FollowCountListing.as_view()),
    path("follow-delete/", FollowDeletion.as_view()),
    path("favorite-shop-create/", FavoriteShopCreation.as_view()),
    path("favorite-shop-listing/", ActiveFavoriteShopListing.as_view()),
    path("favorite-shop-count-listing/", FavoriteShopCountListing.as_view()),
    path(
        "favorite-shop-enduser-count-listing/",
        FavoriteShopEndUserCountListing.as_view(),
    ),
    path("favorite-shop-delete/", FavoriteShopDeletion.as_view()),
    path("favorite-topic-create/", FavoriteTopicCreation.as_view()),
    path("favorite-topic-listing/", ActiveFavoriteTopicListing.as_view()),
    path("favorite-topic-count-listing/", FavoriteTopicCountListing.as_view()),
    path("favorite-topic-delete/", FavoriteTopicDeletion.as_view()),
    

    path("shop-view-increment/", ShopViewIncrement.as_view()),
    path("topic-view-increment/", TopicViewIncrement.as_view()),
    path("review-view-increment/",ReviewViewIncrement.as_view()),
    path("profile-view-increment/",ProfileViewIncrement.as_view()),

    path("favorite-review-create/", FavoriteReviewCreation.as_view()),
    path("favorite-review-delete/", FavoriteReviewDeletion.as_view()),


    #path("shop-review-topic-views/",ReviewTopicShopViewCount.as_view()),

    path("job-application-create/", JobApplicationCreation.as_view()),
    path("job-application-shop-listing/", JobApplicationListing.as_view()),
    path("job-application-enduser-listing/", JobApplicationEndUserListing.as_view()),
    path("job-application-count-listing/", JobApplicationCountListing.as_view()),
    path("job-application-delete/", JobApplicationDeletion.as_view()),
    path("job-application-all-listing/", JobListing.as_view()),
    path("job-application-retrieve/<pk>/",JobRetrieveAPI.as_view()),
    path("job-application-update/",JobApplicationSupoortToggleAPI.as_view())
]


