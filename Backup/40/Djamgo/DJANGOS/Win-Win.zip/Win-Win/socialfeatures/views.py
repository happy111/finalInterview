from .models import *
from .serializers import *
from rest_framework.views import APIView
from rest_framework.generics import (
	CreateAPIView,
	ListAPIView,
	DestroyAPIView,
	UpdateAPIView,
)
from shops.models import Shop
from rest_framework.permissions import IsAuthenticated
from winwin.permissions import IsShopOwner, IsNotBanned, IsPremiumShop, IsSuperAdmin
from rest_framework.response import Response
from rest_framework.status import (
	HTTP_200_OK,
	HTTP_406_NOT_ACCEPTABLE,
	HTTP_401_UNAUTHORIZED,
)
from socialfeatures.models import JobApplication
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from users.models import EndUser

class FollowCreation(CreateAPIView):
	"""
	Follow Creation POST API

		Service Usage and Description : This API is used to create Follow Relationship between 2 end userss.
		Authentication Required : YES

		Data : {
			"followee" : "1",
			"follower" : "2"
		}

		Response : {
			"data" : final_data
		}
	"""

	permission_classes = (IsAuthenticated, IsNotBanned)
	serializer_class = FollowSerializer


class FolloweeListing(ListAPIView):
	"""
	Followee Listing GET API

		Service Usage and Description : This API is used to list active users which a user follows.
		Authentication Required : YES

		Params : {
			"follower" : "2"
		}

		Response : {
			"data" : final_data
		}
	"""

	permission_classes = (IsAuthenticated, IsNotBanned)
	serializer_class = FollowDataSerializer

	def get_queryset(self):
		queryset = Follow.objects.filter(
			follower=self.request.GET.get("follower"),
			followee__active_status=True,
			followee__is_banned=False,
		)
		return queryset


class FollowerListing(ListAPIView):
	"""
	Follower Listing GET API

		Service Usage and Description : This API is used to list active followers of a user.
		Authentication Required : YES

		Params : {
			"followee" : "2"
		}

		Response : {
			"data" : final_data
		}
	"""

	permission_classes = (IsAuthenticated, IsNotBanned)
	serializer_class = FollowDataSerializer

	def get_queryset(self):
		queryset = Follow.objects.filter(
			followee=self.request.GET.get("followee"),
			follower__active_status=True,
			follower__is_banned=False,
		)
		return queryset


class FollowCountListing(ListAPIView):
	"""
	Follow Count Listing GET API

		Service Usage and Description : This API is used to list count of all followees and followers of a user.
		Authentication Required : YES

		Params : {
			"enduser" : "2"
		}

		Response : {
			"data" : final_data
		}
	"""

	permission_classes = (IsAuthenticated, IsNotBanned)
	serializer_class = FollowSerializer

	def get(self, request):
		try:
			user_id = request.GET.get("enduser")
			followers = Follow.objects.filter(
				followee=user_id,
				follower__active_status=True,
				follower__is_banned=False,
			).count()
			followees = Follow.objects.filter(
				follower=user_id,
				followee__active_status=True,
				followee__is_banned=False,
			).count()
			return Response(
				{"success": True, "followers": followers, "followees": followees},
				status=HTTP_200_OK,
			)
		except Exception as e:
			return Response(
				{"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
			)


class FollowDeletion(DestroyAPIView):
	"""
	Follow Deletion DELETE API

		Service Usage and Description : This API is used to delete a Follow relationship.
		Authentication Required : YES

		Data : {
			"id" : "1"
		}
		
		Response : {
			"success": True,
			"message": "Follow Deleted."
		}
	"""

	permission_classes = (IsAuthenticated, IsNotBanned)
	serializer_class = FollowSerializer

	def get_queryset(self):
		queryset = Follow.objects.filter(id=self.request.data["id"])
		return queryset

	def delete(self, request):
		try:
			follow = self.get_queryset()
			if follow.count() == 0:
				raise Exception("No Follow with given id.")
			self.perform_destroy(follow)
			return Response(
				{"success": True, "message": "Follow Relationship Deleted."},
				status=HTTP_200_OK,
			)
		except Exception as e:
			return Response(
				{"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
			)


class FavoriteShopCreation(CreateAPIView):
	"""
	Favorite Shop Creation POST API

		Service Usage and Description : This API is used to create Favorite Shop Relationship between a shop and an enduser.
		Authentication Required : YES

		Data : {
			"shop" : "1",
			"enduser" : "2"
		}

		Response : {
			final_data(list of json)
		}
	"""

	permission_classes = (IsAuthenticated, IsNotBanned)
	serializer_class = FavoriteShopSerializer


class ActiveFavoriteShopListing(ListAPIView):
	"""
	Favorite Shop Listing GET API

		Service Usage and Description : This API is used to list active shop which a user has favorite relationship with.
		Authentication Required : YES

		Params : {
			"enduser" : "2"
		}

		Response : {
			final_data(list of json)
		}
	"""

	permission_classes = (IsAuthenticated, IsNotBanned)
	serializer_class = FavoriteShopDataSerializer

	def get_queryset(self):
		queryset = FavoriteShop.objects.filter(
			enduser=self.request.GET.get("enduser"),
			enduser__active_status=True,
			shop__active_status=True,
			shop__is_banned=False,
		)
		return queryset


class FavoriteShopCountListing(ListAPIView):
	"""
	Favorite Shop Count Listing GET API

		Service Usage and Description : This API is used to list count of all shops that have a favorite relationship with the enduser.
		Authentication Required : YES

		Params : {
			"enduser" : "1"
		}

		Response : {
			"success"  : true,
			"shops"     : 2
		}
	"""

	permission_classes = (IsAuthenticated, IsNotBanned)
	serializer_class = FavoriteShopSerializer

	def get(self, request):
		try:
			shops = FavoriteShop.objects.filter(
				enduser=request.GET.get("enduser"), enduser__active_status=True,
			).count()
			return Response({"success": True, "shops": shops}, status=HTTP_200_OK,)
		except Exception as e:
			return Response(
				{"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
			)


class FavoriteShopEndUserCountListing(ListAPIView):
	"""
	Favorite Shop End Users Count Listing GET API

		Service Usage and Description : This API is used to list count of all endusers that have a favorite relationship with the shop.
		Authentication Required : YES

		Params : {
			"shop" : "1"
		}

		Response : {
			"success"  : true,
			"endusers"     : 2
		}
	"""

	permission_classes = (IsAuthenticated, IsShopOwner)
	serializer_class = FavoriteShopSerializer

	def get(self, request):
		try:
			endusers = FavoriteShop.objects.filter(
				shop=request.GET.get("shop"),
				shop__active_status=True,
				shop__is_banned=False,
			).count()
			return Response(
				{"success": True, "endusers": endusers}, status=HTTP_200_OK,
			)
		except Exception as e:
			return Response(
				{"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
			)


class FavoriteShopDeletion(DestroyAPIView):
	"""
	Favorite Shop Deletion DELETE API

		Service Usage and Description : This API is used to delete a Favorite Shop relationship.
		Authentication Required : YES

		Data : {
			"id" : "1"
		}
		
		Response : {
			"success": True,
			"message": "Favorite Shop relationship Deleted."
		}
	"""

	permission_classes = (IsAuthenticated, IsNotBanned)
	serializer_class = FavoriteShopSerializer

	def get_queryset(self):
		queryset = FavoriteShop.objects.filter(id=self.request.data["id"])
		return queryset

	def delete(self, request):
		try:
			favoriteShop = self.get_queryset()
			if favoriteShop.count() == 0:
				raise Exception("No Favorite Shop relationship with given id.")
			self.perform_destroy(favoriteShop)
			return Response(
				{"success": True, "message": "Favorite Shop Relationship Deleted."},
				status=HTTP_200_OK,
			)
		except Exception as e:
			return Response(
				{"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
			)


class FavoriteTopicCreation(CreateAPIView):
	"""
	Favorite Topic Creation POST API

		Service Usage and Description : This API is used to create Favorite Topic Relationship between a topic and an enduser.
		Authentication Required : YES

		Data : {
			"topic" : "1",
			"enduser" : "2"
		}

		Response : {
			final_data(list of json)
		}
	"""

	permission_classes = (IsAuthenticated, IsNotBanned)
	serializer_class = FavoriteTopicSerializer


class ActiveFavoriteTopicListing(ListAPIView):
	"""
	Favorite Topic Listing GET API

		Service Usage and Description : This API is used to list active topic which a user has favorite relationship with.
		Authentication Required : YES

		Params : {
			"enduser" : "2"
		}

		Response : {
			final_data(list of json)
		}
	"""

	permission_classes = (IsAuthenticated, IsNotBanned)
	serializer_class = FavoriteTopicDataSerializer

	def get_queryset(self):
		queryset = FavoriteTopic.objects.filter(
			enduser=self.request.GET.get("enduser"),
			enduser__active_status=True,
			topic__active_status=True,
		)
		return queryset


class FavoriteTopicCountListing(ListAPIView):
	"""
	Favorite Topic Count Listing GET API

		Service Usage and Description : This API is used to list count of active topics that have a favorite relationship with the enduser.
		Authentication Required : YES

		Params : {
			"enduser" : "1"
		}

		Response : {
			"success"  : true,
			"topics"     : 2
		}
	"""

	permission_classes = (IsAuthenticated, IsNotBanned)
	serializer_class = FavoriteTopicSerializer

	def get(self, request):
		try:
			topics = FavoriteTopic.objects.filter(
				enduser=request.GET.get("enduser"),
				enduser__active_status=True,
				topic__active_status=True,
			).count()
			return Response({"success": True, "topics": topics}, status=HTTP_200_OK,)
		except Exception as e:
			return Response(
				{"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
			)


class FavoriteTopicDeletion(DestroyAPIView):
	"""
	Favorite Topic Deletion DELETE API

		Service Usage and Description : This API is used to delete a Favorite Topic relationship.
		Authentication Required : YES

		Data : {
			"id" : "1"
		}
		
		Response : {
			"success": True,
			"message": "Favorite Topic relationship Deleted."
		}
	"""

	permission_classes = (IsAuthenticated, IsNotBanned)
	serializer_class = FavoriteTopicSerializer

	def get_queryset(self):
		queryset = FavoriteTopic.objects.filter(id=self.request.data["id"])
		return queryset

	def delete(self, request):
		try:
			favoriteTopic = self.get_queryset()
			if favoriteTopic.count() == 0:
				raise Exception("No Favorite Topic relationship with given id.")
			self.perform_destroy(favoriteTopic)
			return Response(
				{"success": True, "message": "Favorite Topic Relationship Deleted."},
				status=HTTP_200_OK,
			)
		except Exception as e:
			return Response(
				{"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
			)


class ShopViewIncrement(APIView):
	"""
	Shop View Increment POST API

		Service Usage and Description: This API is used to increase the view count for a shop.
		Authentication Rqequired: YES

		Data : {
			"shop" : 1,
			"enduser" : 1
		}

		Response : {
			"success" : True
			"message" : "View count incremented."
		}
	"""

	permission_classes = (IsAuthenticated, IsNotBanned)

	def post(self, request):
		try:
			shop = Shop.objects.filter(id=request.data["shop"])
			if shop.count() == 0:
				raise Exception("No Shop with given id.")
			shop = shop.first()
			shopViews = ShopViews.objects.filter(
				shop=shop, enduser__id=request.data["enduser"]
			)
			if shopViews.count():
				return Response(
					{"success": True, "message": "A view exists in current cycle."},
					status=HTTP_200_OK,
				)
			if shop.views_count != None:
				shop.views_count = shop.views_count + 1
			else:
				shop.views_count = 1
			data = {}
			data["shop"] = shop.id
			data["enduser"] = request.data["enduser"]
			serializer = ShopViewsSerializer(data=data)
			if serializer.is_valid(raise_exception=True):
				serializer.save()
				shop.save()
				return Response(
					{"success": True, "message": "View count incremented."},
					status=HTTP_200_OK,
				)
			return Response({"name": shop.views_count})
		except Exception as e:
			return Response(
				{"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
			)

class ReviewViewIncrement(APIView):
	"""
	Review View Increment POST API
		usage: This API is used to increase the view count for the review.
		Data : {
			"review" : 1,
			"enduser" : 1
		}

		Response : {
			"success" : True,
			"message" : "View Count incremented."
		}
	"""
	permission_classes = (IsAuthenticated, IsNotBanned)

	def post(self,request):
		try:
			review = Review.objects.filter(id=request.data["review"])
			if review.count() == 0:
				raise Exception("No Review with given id")
			review = review.first()
			reviewViews = ReviewViews.objects.filter(
				review = review , enduser__id=request.data["enduser"]
			)
			if reviewViews.count():
				return Response(
					{"success": True, "message": 'A view exists in current cycle.'},
					status=HTTP_200_OK,
				)
			if review.views_count != None:
				review.views_count = review.views_count +1
			else:
				review.views_count  = 1
			data = {}
			data["review"] = review.id
			data["enduser"] = request.data["enduser"]
			serializer = ReviewViewSerializer(data=data)
			if serializer.is_valid(raise_exception=True):
				serializer.save()
				review.save()
				return Response(
					{"success": True, "message": "View count incremented."},
					status=HTTP_200_OK,
				)
			return Response({"name": review.views_count})
		except Exception as e:
			return Response(
				{"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
			)


class TopicViewIncrement(APIView):
	"""
	Topic View Increment POST API

		Service Usage and Description: This API is used to increase the view count for a topic.
		Authentication Rqequired: YES

		Data : {
			"topic" : 1,
			"enduser" : 1
		}

		Response : {
			"success" : True
			"message" : "View count incremented."
		}
	"""

	permission_classes = (IsAuthenticated, IsNotBanned)

	def post(self, request):
		try:
			topic = Topic.objects.filter(id=request.data["topic"])
			if topic.count() == 0:
				return Response(
					{"success": True, "message": "No Topic with given id."},
					status=HTTP_200_OK,
				)
			topic = topic.first()
			topicViews = TopicViews.objects.filter(
				topic=topic, enduser__id=request.data["enduser"]
			)
			if topicViews.count():
				return Response(
					{"success": True, "message": "A view exists in current cycle."},
					status=HTTP_200_OK,
				)
			if topic.views_count != None:
				topic.views_count = topic.views_count + 1
			else:
				topic.views_count = 1
			data = {}
			data["topic"] = topic.id
			data["enduser"] = request.data["enduser"]
			serializer = TopicViewsSerializer(data=data)
			if serializer.is_valid(raise_exception=True):
				serializer.save()
				topic.save()
				return Response(
					{"success": True, "message": "View count incremented."},
					status=HTTP_200_OK,
				)
			return Response({"name": topic.views_count})
		except Exception as e:
			return Response(
				{"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
			)

class ReviewTopicShopViewCount(APIView):
	"""
	Review Topic and Shop Views GET API

		Usage : Get Count of the Shop Views, Reviews & Topic Views related to Shop

		Authentication Required : YES
		 Params : {
			"shop"  :   "1"
		}

		Response : {
			"success" : true,
			"review_views" : 1,
			"shop_views" : 1,
			"topic_views" : 1,
		}
	"""

	permission_classes = (IsAuthenticated, IsNotBanned | IsShopOwner)

	def get(self,requests):
		try:
			reviews = Review.objects.filter(shop=self.request.GET.get("shop"))
			topics = Topic.objects.filter(shop=self.request.GET.get("shop"))
			shop = Shop.objects.filter(id=self.request.GET.get("shop"))

			reviews_count = 0
			for rev in reviews:
				reviews_count = reviews_count + rev.views_count
			topics_count = 0
			for tp in topics:
				topics_count = topics_count + tp.views_count
			shop_count = shop[0].views_count
			return Response(
				{"sucess" : True,"review_views" : reviews_count,"shop_views" : shop_count,"topic_views" : topics_count},status=HTTP_200_OK
			)
		except Exception as e:
			return Response(
				{"success": False,"message" : str(e)},status=HTTP_406_NOT_ACCEPTABLE
			)
class JobApplicationCreation(CreateAPIView):
	"""
	Job Application Creation POST API

		Service Usage and Description: This API is used to create a job application for a shop by an enduser.
		Authentication Required: YES

		Data : {
			"shop" : 1,
			"enduser" : 1,
			"email" : "mratyunjay.soni@eoraa.com",
			"content" : "Hi, Please contact me if there is a vacancy for a Chef.",
			"phone_number" : "+919711457991"
		}

		Response : {
			final_Data
		}
	"""

	permission_classes = (IsAuthenticated, IsNotBanned)
	serializer_class = JobApplicationSerializer


class JobApplicationListing(ListAPIView):
	"""
	Active Job Application Listing GET API

		Service Usage and Description: This API is used to list all the active job applications for a shop.
		Authentication Required: YES

		Params : {
			"shop"  : 1
		}

		Response : {
			data(list of json)
		}
	"""

	permission_classes = (IsAuthenticated, IsShopOwner, IsPremiumShop)
	serializer_class = JobApplicationDataSerializer

	def get_queryset(self):
		queryset = JobApplication.objects.filter(
			active_status=True, shop__id=self.request.GET.get("shop")
		)
		return queryset


class JobApplicationEndUserListing(ListAPIView):
	"""
	Active Job Application Listing GET API

		Service Usage and Description: This API is used to list all the active job applications for an enduser.
		Authentication Required: YES

		Params : {
			"enduser"  : 1
		}

		Response : {
			data(list of json)
		}
	"""

	permission_classes = (IsAuthenticated, IsNotBanned)
	serializer_class = JobApplicationDataSerializer

	def get_queryset(self):
		queryset = JobApplication.objects.filter(
			active_status=True, enduser__id=self.request.GET.get("enduser")
		)
		return queryset






class JobApplicationCountListing(ListAPIView):
	"""
	Job Applications Count Listing GET API

		Service Usage and Description : This API is used to list count of active job applications for a shop.
		Authentication Required : YES

		Params : {
			"shop" : "1"
		}

		Response : {
			"success"  : true,
			"job applications"     : 1
		}
	"""

	permission_classes = (IsAuthenticated, IsShopOwner, IsPremiumShop)
	serializer_class = JobApplicationSerializer

	def get(self, request):
		try:
			jobApplications = JobApplication.objects.filter(
				shop=request.GET.get("shop"),
				enduser__active_status=True,
				enduser__is_banned=False,
				active_status=True,
			).count()
			return Response(
				{"success": True, "job applications": jobApplications},
				status=HTTP_200_OK,
			)
		except Exception as e:
			return Response(
				{"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
			)


class JobApplicationDeletion(DestroyAPIView):
	"""
	Job Application Deletion DELETE API

		Service Usage and Description : This API is used to delete a Job Application.
		Authentication Required : YES

		Data : {
			"id" : "1"
		}
		
		Response : {
			"success": True,
			"message": "Job Application Deleted."
		}
	"""

	permission_classes = (IsAuthenticated, IsNotBanned)
	serializer_class = FavoriteTopicSerializer

	def get_queryset(self):
		queryset = JobApplication.objects.filter(
			active_status=True, id=self.request.data["id"]
		)
		return queryset

	def delete(self, request):
		try:
			jobApplication = self.get_queryset()
			if jobApplication.count() == 0:
				raise Exception("No Job Application with given id.")
			queryset = jobApplication.first()
			queryset.active_status = False
			queryset.save()
			return Response(
				{"success": True, "message": "Job Application Deleted."},
				status=HTTP_200_OK,
			)
		except Exception as e:
			return Response(
				{"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
			)


class ProfileViewIncrement(APIView):
	"""
	Profile View Increment POST API
		usage: This API is used to increase the view count for the profile.
		Data : {
			"enduser" : 1,
			"profile" : 1
		}

		Response : {
			"success" : True,
			"message" : "View Count incremented."
		}
	"""
	permission_classes = (IsAuthenticated, IsNotBanned)
	def post(self,request):
		try:
			view = EndUser.objects.filter(id=request.data["enduser"])
			if view.count() == 0:
				raise Exception("No Profile with given id")
			view = view.first()
			reviewViews = ProfileView.objects.filter(
				profile = request.data['profile'] , enduser__id=request.data["enduser"]
			)
			if reviewViews.count():
				return Response(
					{"success": True, "message": "A view exists in current cycle."},
					status=HTTP_200_OK,
				)
			view.views_count = view.views_count +1
			data = {}
			data["enduser"] = request.data["enduser"]
			data["profile"] = request.data["profile"]
			serializer = ProfileSerializer(data=data)
			if serializer.is_valid(raise_exception=True):
				serializer.save()
				review.save()
				return Response(
					{"success": True, "message": "View count incremented."},
					status=HTTP_200_OK,
				)
			return Response({"name": view.views_count})
		except Exception as e:
			return Response(
				{"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
			)


class JobListing(ListAPIView):
	"""
	Active Job Application Listing GET API

		Service Usage and Description: This API is used to list all the active job applications for a shop.
		Authentication Required: YES

		Params:  {
			"page_no": 1,
			"page_size": 10,
		}

		Response : {
			data(list of json)
		}
	"""

	permission_classes = (IsAuthenticated,)
	serializer_class = JobApplicationDataSerializer

	def get(self, request):
		try:
			p_no= self.request.GET.get("page_no")
			p_size = self.request.GET.get("page_size")
			page_no = 1
			page_size = 10
			job_data = JobApplication.objects.filter()
			final_data = []
			page_info = {}
			if job_data.count() > 0:
				if p_no != None:
					page_no = int(self.request.GET.get("page_no"))
				if p_size != None:
					page_size = int(self.request.GET.get("page_size"))
				try:
					if page_size > 200:
						page_size = 200
					pages = Paginator(job_data, page_size)
					job_data = pages.page(page_no)
				except PageNotAnInteger:
					page_no = 1
					job_data = pages.page(page_no)
				except EmptyPage:
					page_no = pages.num_pages
					job_data = pages.page(page_no)
				page_count = pages.count
				page_info = {
					"page_no": page_no,
					"page_size": page_size,
					"total_job": page_count,
					"total_pages" : pages.num_pages
				}
				for index in range(len(job_data.object_list)):
					p_list ={}
					p_list['id'] = job_data[index].id
					p_list['enduser'] = job_data[index].enduser.name if job_data[index].enduser else ''
					p_list['content'] = job_data[index].content
					p_list['shop'] =  job_data[index].shop.name if job_data[index].shop else ''
					p_list['active_status'] = job_data[index].active_status
					p_list['phone_number'] = job_data[index].phone_number
					p_list['avatar'] = job_data[index].enduser.avatar if job_data[index].enduser else ''
					p_list['age'] = job_data[index].enduser.age if job_data[index].enduser else ''
					p_list['created_at'] = job_data[index].created_at
					p_list['email'] = job_data[index].email
					final_data.append(p_list)
			return Response(
				{"success": True, 
				"data": final_data,
				"page": page_info}, status=HTTP_200_OK
			)
		except Exception as e:
			return Response(
				{"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
			)



class FavoriteReviewCreation(CreateAPIView):
	"""
	Favorite Review Creation POST API

		Service Usage and Description : This API is used to create Favorite Review Relationship between a review and an enduser.
		Authentication Required : YES

		Data : {
			"review" : "1",
			"enduser" : "2"
		}

		Response : {
			final_data(list of json)
		}
	"""

	permission_classes = (IsAuthenticated, IsNotBanned)
	serializer_class = FavoriteReviewSerializer



class FavoriteReviewDeletion(DestroyAPIView):
	"""
	Favorite Topic Deletion DELETE API

		Service Usage and Description : This API is used to delete a Favorite Topic relationship.
		Authentication Required : YES

		Data : {
			"id" : "1"
		}
		
		Response : {
			"success": True,
			"message": "Favorite Topic relationship Deleted."
		}
	"""

	permission_classes = (IsAuthenticated, IsNotBanned)
	serializer_class = FavoriteTopicSerializer

	def get_queryset(self):
		queryset = FavoriteReview.objects.filter(id=self.request.data["id"])
		return queryset

	def delete(self, request):
		try:
			favoriteTopic = self.get_queryset()
			if favoriteTopic.count() == 0:
				raise Exception("No Favorite Review relationship with given id.")
			self.perform_destroy(favoriteTopic)
			return Response(
				{"success": True, "message": "Favorite Review Relationship Deleted."},
				status=HTTP_200_OK,
			)
		except Exception as e:
			return Response(
				{"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
			)

class JobApplicationSupoortToggleAPI(UpdateAPIView):
	"""
	JobApplication update API

	Data {
		"id" : 1,
		"shop_id" : 1,
		"is_supported" : true
	}
	"""

	serializer_class = JobApplicationSerializer

	def put(self,request):
		try:
			data = request.data
			job_data = JobApplication.objects.filter(id=data["id"],shop=data["shop_id"])
			if job_data.count() == 0:
				raise Exception("No Job Application with given id.")
			serializer = JobApplicationSerializer(job_data[0], data=data, partial=True)
			if serializer.is_valid(raise_exception=True):
				serializer.save()
				return Response(
					{"success": True, "message": "Job Application Updated."},
					status=HTTP_200_OK,
				)
		except Exception as e:
			return Response(
				{"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
			)

class JobRetrieveAPI(APIView):
	"""
	Job Retrieve API

		Usage: THis API is used to get job details.
		Authentication Required: YES

		param: {
			
		}
		response: {
			final_data(list of json)
		}
	"""

	permission_classes = (
		IsAuthenticated, IsSuperAdmin | IsShopOwner
	)

	def get_object(self, pk):
		try:
			return JobApplication.objects.get(pk=pk)
		except JobApplication.DoesNotExist:
			raise Http404

	def get(self, request, pk, format=None):
		try:
			job_profile = self.get_object(pk)
			final_data = []
			job_application = JobApplication.objects.filter(id =job_profile.id)
			end_user = EndUser.objects.filter(id = job_profile.enduser.id)
			for job in job_application:
				temp = {}
				temp["shop ID"] = job.shop.id
				temp["shop Name"] = job.shop.name
				temp["EndUser Name"] = job.enduser.name
				temp["EndUser ID"] = job.enduser.id
				temp["age"] = job.enduser.age
				temp["avatar"] = job.enduser.avatar
				temp["Content"] = job.content
				temp["Email"] = job.email
				temp["Phone Number"] = job.phone_number
				temp["Created AT"] = job.created_at
				final_data.append(temp)
			return Response(final_data, status=HTTP_200_OK)
		except Exception as e:
			return Response(
				{"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
			)