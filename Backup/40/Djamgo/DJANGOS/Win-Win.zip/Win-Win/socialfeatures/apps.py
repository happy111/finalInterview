from django.apps import AppConfig


class SocialfeaturesConfig(AppConfig):
    name = "socialfeatures"
