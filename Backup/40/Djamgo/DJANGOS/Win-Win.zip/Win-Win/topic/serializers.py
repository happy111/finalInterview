from rest_framework import serializers
from .models import Topic, TopicLike, TopicComment, TopicDeleteReason
from users.serializers import EndUserNameSerializer, UserSerializer

class TopicSerializer(serializers.ModelSerializer):
    class Meta:
        model = Topic
        fields = "__all__"

class TopicDataSerializer(serializers.ModelSerializer):
    enduser = EndUserNameSerializer()
    class Meta:
        model = Topic
        fields = "__all__"

class TopicNameSerializer(serializers.ModelSerializer):
    class Meta:
        model = Topic
        fields = ("id", "title")

class TopicLikeSerializer(serializers.ModelSerializer):
    class Meta:
        model = TopicLike
        fields = "__all__"


class TopicCommentSerializer(serializers.ModelSerializer):
    class Meta:
        model = TopicComment
        fields = "__all__"

class TopicDeleteSerializer(serializers.ModelSerializer):
    class Meta:
        model = TopicDeleteReason
        fields = "__all__"