from .models import *
from .serializers import (
    TopicSerializer,
    TopicCommentSerializer,
    TopicLikeSerializer,
    TopicDeleteSerializer,
)
from rest_framework.views import APIView
from rest_framework.generics import (
    CreateAPIView,
    ListAPIView,
    DestroyAPIView,
    UpdateAPIView,
)
from rest_framework.permissions import IsAuthenticated
from winwin.permissions import IsShopOwner, IsNotBanned, IsSuperAdmin
from rest_framework.response import Response
from rest_framework.status import (
    HTTP_200_OK,
    HTTP_406_NOT_ACCEPTABLE,
    HTTP_401_UNAUTHORIZED,
)
import json
from socialfeatures.models import Follow,TopicViews
from socialfeatures.models import Follow,TopicViews
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from datetime import datetime, timedelta
from users.serializers import *

class TopicCreation(CreateAPIView):
    """
    Topic Creation POST API

        Service Usage and Description : This API is used to create Topic.
        Authentication Required : YES

        Data : {
            "enduser" : "1",
            "area"  :   "1",
            "genre" :   "1",
            "title" :   "sgsegslagl",
            "content"   :   "rhbDJBKebnjeanbe"
        }

        Response : {
            "data" : final_data
        }
    """

    permission_classes = (IsAuthenticated, IsNotBanned)
    serializer_class = TopicSerializer
    # def post(self,request):
    #     data = request.data)


class ActiveTopicListing(ListAPIView):
    """
    Active Topic Listing GET API

        Service Usage and Description : This API is used to list active Topics.
        Authentication Required : YES

        Params : {
            "area"  :   "1", (optional)
            "genre" : "1",  (optional)
            "shop" : "1"  (optional)
            "enduser" : "1" (optional)
        }

        Response : {
            "data" : final_data
        }
    """

    permission_classes = (IsAuthenticated, IsNotBanned | IsShopOwner | IsSuperAdmin)
    serializer_class = TopicSerializer

    def get_queryset(self):
        shop = self.request.GET.get("shop")
        area = self.request.GET.get("area")
        genre = self.request.GET.get("genre")
        enduser = self.request.GET.get("enduser")
        queryset = Topic.objects.filter(active_status=True)
        orderbyList = ['-is_pinned_by_user','-id']
        if area != None:
            queryset = queryset.filter(area=area).order_by(*orderbyList)
        if shop != None:
            queryset = queryset.filter(shop=shop).order_by(*orderbyList)
        if genre != None:
            queryset = queryset.filter(genre=genre).order_by(*orderbyList)
        if enduser != None:
            queryset = queryset.filter(enduser=enduser).order_by(*orderbyList)
        if area == None and shop == None and genre == None and enduser == None:
            queryset = Topic.objects.filter(active_status=True).order_by(*orderbyList)
        return queryset

    def get(self, request):
        try:
            queryset = self.filter_queryset(self.get_queryset())
            final_data = []
            user = request.user
            enduser = EndUser.objects.filter(auth_user=user)
            enduser_id = None
            if enduser.count():
                enduser_id = enduser[0].id
            top_viewer = TopViewer(queryset)
            for topic in queryset:
                temp = {}
                temp["id"] = topic.id
                topic_count = TopicViews.objects.filter(
                    topic_id=topic.id)
                if topic_count.count() > 0:
                    temp["topic_view_count"] = topic_count.count()
                else:
                    temp["topic_view_count"] = 0
                # temp["genre_id"] = topic.genre.id
                # temp["genre"] = topic.genre.name
                # temp["area_id"] = topic.area.id
                # temp["area"] = topic.area.name
                temp["title"] = topic.title
                temp["content"] = topic.content
                temp["shop"] = None
                if topic.shop:
                    temp["shop"] = topic.shop.id
                    temp["shop_name"] = topic.shop.name
                temp["enduser"] = {}
                temp["enduser"]["id"] = topic.enduser.id

                if topic.enduser.id == enduser_id:
                    fcount = Follow.objects.filter(followee=topic.enduser.id)
                    temp["enduser"]["follower_count"] = fcount.count()
                else:
                    fcount = Follow.objects.filter(followee=topic.enduser.id)
                    temp["enduser"]["follower_count"] = fcount.count()

                    followExist = Follow.objects.filter(followee=topic.enduser.id, follower=enduser_id)
                    temp["enduser"]["is_followed"] = False
                    if followExist.count():
                        temp["enduser"]["is_followed"] = True
                        temp["enduser"]["follow_id"] = followExist[0].id
                temp["enduser"]["name"] = topic.enduser.name
                temp["enduser"]["username"] = topic.enduser.auth_user.username
                temp["enduser"]["avatar"] = topic.enduser.avatar
                temp["is_pinned_by_user"] = topic.is_pinned_by_user
                temp["is_pinned_by_shop"] = topic.is_pinned_by_shop
                temp["is_report"]=topic.is_report
                temp["active_status"]=topic.active_status
                temp["is_hidden"]=topic.is_hidden
                temp["active_status"] = topic.active_status
                temp["hashtags"] = topic.hashtags
                temp["like_count"] = TopicLike.objects.filter(topic=topic).count()
                if temp['like_count'] in top_viewer:
                    temp['top_viewer'] = True
                else:
                    temp['top_viewer'] = False
 
                temp["is_liked"] = False
                likeExist = TopicLike.objects.filter(
                    topic=topic, enduser__id=enduser_id
                )
                if likeExist.count():
                    temp["is_liked"] = True
                    temp["like_id"] = likeExist[0].id
                temp["comment_count"] = TopicComment.objects.filter(topic=topic).count()
                temp["is_favorite"] = False
                from socialfeatures.models import FavoriteTopic
                favoriteExist = FavoriteTopic.objects.filter(
                    topic=topic, enduser__id=enduser_id
                )
                if favoriteExist.count():
                    temp["is_favorite"] = True
                    temp["favorite_id"] = favoriteExist[0].id
                    fav_count = FavoriteTopic.objects.filter(
                    topic=topic)
                    temp["favorite_count"] = fav_count.count()
                else:
                     temp["favorite_count"] = 0
                

                created_at = topic.created_at+timedelta(hours=5,minutes=30)
                temp["created_at"] = created_at.strftime("%Y/%m/%d %I:%M %p")
                temp["updated_at"] = topic.updated_at.strftime("%Y/%m/%d %I:%M %p")
                final_data.append(temp)
            return Response(final_data, status=HTTP_200_OK)
        

        except Exception as e:
            return Response(
                {"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
            )

class AllTopicListing(ListAPIView):
    """
    All Topic Listing GET API

        Service Usage and Description : This API is used to list active Topics.
        Authentication Required : YES

        Params : {
            "area"  :   "1", (optional)
            "genre" : "1",  (optional)
            "shop" : "1"  (optional)
            "enduser" : "1" (optional)
        }

        Response : {
            "data" : final_data
        }
    """

    permission_classes = (IsAuthenticated, IsNotBanned | IsShopOwner | IsSuperAdmin)
    serializer_class = TopicSerializer

    def get_queryset(self):
        shop = self.request.GET.get("shop")
        area = self.request.GET.get("area")
        genre = self.request.GET.get("genre")
        enduser = self.request.GET.get("enduser")
        queryset = Topic.objects.all()
        if area != None:
            queryset = queryset.filter(area=area)
        if shop != None:
            queryset = queryset.filter(shop=shop)
        if genre != None:
            queryset = queryset.filter(genre=genre)
        if enduser != None:
            queryset = queryset.filter(enduser=enduser)
        if area == None and shop == None and genre == None and enduser == None:
            queryset = Topic.objects.filter(active_status=True).order_by('-id')
        return queryset

    def get(self, request):
        try:
            queryset = self.filter_queryset(self.get_queryset())
            # if queryset.count() == 0:
            #     raise Exception("No topics found.")
            final_data = []
            user = request.user
            enduser = EndUser.objects.filter(auth_user=user)
            enduser_id = None
            if enduser.count():
                enduser_id = enduser[0].id
            for topic in queryset:
                temp = {}
                temp["id"] = topic.id
                temp["genre_id"] = topic.genre.id
                temp["genre"] = topic.genre.name
                temp["area_id"] = topic.area.id
                temp["area"] = topic.area.name
                temp["title"] = topic.title
                temp["content"] = topic.content
                temp["is_report"]=topic.is_report
                temp["remark"] = topic.remark
                temp["active_status"]=topic.active_status
                temp["is_hidden"]=topic.is_hidden
                temp["shop"] = None
                if topic.shop:
                    temp["shop"] = topic.shop.id
                    temp["shop_name"] = topic.shop.name
                temp["enduser"] = {}
                temp["enduser"]["id"] = topic.enduser.id
                temp["enduser"]["name"] = topic.enduser.name
                temp["enduser"]["username"] = topic.enduser.auth_user.username
                temp["enduser"]["avatar"] = topic.enduser.avatar
                temp["is_pinned_by_user"] = topic.is_pinned_by_user
                temp["is_pinned_by_shop"] = topic.is_pinned_by_shop
                temp["active_status"] = topic.active_status
                temp["like_count"] = TopicLike.objects.filter(topic=topic).count()
                temp["is_liked"] = False
                likeExist = TopicLike.objects.filter(
                    topic=topic, enduser__id=enduser_id
                )
                if likeExist.count():
                    temp["is_liked"] = True
                    temp["like_id"] = likeExist[0].id
                temp["comment_count"] = TopicComment.objects.filter(topic=topic).count()
                temp["is_favorite"] = False
                from socialfeatures.models import FavoriteTopic

                favoriteExist = FavoriteTopic.objects.filter(
                    topic=topic, enduser__id=enduser_id
                )
                if favoriteExist.count():
                    temp["is_favorite"] = True
                    temp["favorite_id"] = favoriteExist[0].id
                created_at = topic.created_at+timedelta(hours=5,minutes=30)
                temp["created_at"] = created_at.strftime("%Y/%m/%d %I:%M %p")
                temp["updated_at"] = topic.updated_at.strftime("%Y/%m/%d %I:%M %p")
                final_data.append(temp)
           

            return Response(final_data, status=HTTP_200_OK)
        

        except Exception as e:
            return Response(
                {"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
            )

class TopicCancellatonRequest(APIView):
    """
    Topic Cancel Request API

        Usage: This API is used by shopOwner to request of delete of topic using id.
        Authentication Required : YES

    body : {
        "topic" : 1,
        "shop" : 1,
        "reason" : "Delete it Please!"
    }
    response: {
        "success" : true,
        "message" : "requested for delete"
    }
    """
    permission_classes = (IsAuthenticated, IsShopOwner | IsNotBanned | IsSuperAdmin)
    def post(self,request):
        try:
            data = json.loads(request.body)
            topic = Topic.objects.filter(id=data['topic'])
            shop = Shop.objects.filter(id=data['shop'])
            if topic.count() == 0:
                raise Exception("No Topic with given id.")
            topic = topic.first()
            if topic.is_report == False:
                reason = {}
                reason['shop'] = data['shop']
                reason['topic'] = data['topic']
                reason['reason'] = data['reason']
                topic.is_report = True
                topic.remark = "Requested for deletion"
                serializer = TopicDeleteSerializer(data=reason)
                if serializer.is_valid(raise_exception=True):
                    serializer.save()
                    topic.save()
                    return Response({"success":True,"message":"The topic has been reported"})
            else:
                return Response({"success":True,"message":"Already Reported."})        
        
        except Exception as e:
            return Response(
                {"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
            )
            
class TopicReasonDeleteAPI(APIView):
    """
    Topic Delete Requested By ShopOwner API 

        Usage: THis API is used by SuperAdmin to delete the Topic requested by shopowner.

        body: {
            "approved" : true,
        }
        response: {
            "success":true,
            "message": "Topic Deleted"
        }
    """

    permission_classes = (
        IsAuthenticated, IsSuperAdmin
    )

    def get_object(self, pk):
        try:
            return TopicDeleteReason.objects.get(pk=pk)
        except TopicDeleteReason.DoesNotExist:
            raise Http404

    def delete(self, request, pk, format=None):
        try:
            topic_reason = self.get_object(pk)
            data = json.loads(request.body)
            if data['approved'] == True:
                topic = Topic.objects.filter(id =topic_reason.topic.id)
                reason_topic = TopicDeleteReason.objects.filter(id = topic_reason.id)
                if topic.count() == 0:
                    raise Exception("No Topic with given id.")
                topic = topic.first()
                reason_topic = reason_topic.first()
                topic.is_report = False
                topic.remark = "この投稿は削除されました"
                topic.active_status = False
                reason_topic.active_status = False
                reason_topic.save()
                topic.save()
                return Response({"success":True,"message":"The topic has been Deleted"})
            else:
                topic = Topic.objects.filter(id =topic_reason.topic.id)
                reason_topic = TopicDeleteReason.objects.filter(id = topic_reason.id)
                if topic.count() == 0:
                    raise Exception("No Topic with given id.")
                topic = topic.first()
                reason_topic = reason_topic.first()
                topic.is_report = False
                topic.remark = "削除申請は却下されました。"
                reason_topic.active_status = False
                reason_topic.save()
                topic.save()
                return Response({"success":True,"message":"Not Approved"})

        except Exception as e:
            return Response(
                {"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
            )

class TopicDeleteAPI(APIView):
    """
    Topic Delete API
        Usage: THis API is used by SuperAdmin to delete the Topic.

        body: {
            "approved" : true,
        }
        response: {
            "success":true,
            "message": "Topic Deleted"
        }
    """
    permission_classes = (
        IsAuthenticated, IsSuperAdmin
    )
    
    def get_object(self, pk):
        try:
            return Topic.objects.get(pk=pk)
        except Topic.DoesNotExist:
            raise Http404

    def delete(self, request, pk, format=None):
        try:
            topic = self.get_object(pk)
            data = json.loads(request.body)
            if data['approved'] == True:
                print(topic.id)
                topic = Topic.objects.filter(id =topic.id)
                if topic.count() == 0:
                    raise Exception("No Topic with given id.")
                topic = topic.first()
                topic.active_status = False
                topic.save()
                return Response({"success":True,"message":"The topic has been Deleted"})
            else:
                return Response({"success":True,"message":"Not Approved"})

        except Exception as e:
            return Response(
                {"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
            )

class TopicDataListing(ListAPIView):
    """
    Topic Data Listing GET API

        Service Usage and Description : This API is used to list the data for a topic using id.
        Authentication Required : YES

        Params  :   {
            "topic" : 1
        }

        Response : {
            final_data(list of json)
        }
    """

    permission_classes = (IsAuthenticated, IsShopOwner | IsNotBanned | IsSuperAdmin)
    serializer_class = TopicSerializer

    def get_queryset(self):
        queryset = Topic.objects.filter(id=self.request.GET.get("topic"))
        return queryset

    def get(self, request):
        try:
            queryset = self.filter_queryset(self.get_queryset())
            final_data = []
            user = request.user
            enduser = EndUser.objects.filter(auth_user=user)
            enduser_id = None
            if enduser.count():
                enduser_id = enduser[0].id
            for topic in queryset:
                temp = {}
                temp["id"] = topic.id
                temp["genre"] = topic.genre.name if topic.genre else ''
                temp["area"] = topic.area.name if topic.area else ''
                temp["title"] = topic.title 
                temp["content"] = topic.content
                temp["shop"] = None
                try:
                    temp["shop"] = topic.shop.id
                    temp["shop_name"] = topic.shop.name
                except Exception as e:
                    print(str(e))
                temp["enduser"] = {}
                temp["enduser"]["id"] = topic.enduser.id
                temp["enduser"]["name"] = topic.enduser.name
                temp["enduser"]["username"] = topic.enduser.auth_user.username
                temp["enduser"]["avatar"] = topic.enduser.avatar
                temp["is_pinned_by_user"] = topic.is_pinned_by_user
                temp["is_pinned_by_shop"] = topic.is_pinned_by_shop
                temp["like_count"] = TopicLike.objects.filter(topic=topic).count()
                temp["is_liked"] = False
                likeExist = TopicLike.objects.filter(
                    topic=topic, enduser__id=enduser_id
                )
                if likeExist.count():
                    temp["is_liked"] = True
                    temp["like_id"] = likeExist[0].id
                temp["comment_count"] = TopicComment.objects.filter(topic=topic).count()
                temp["is_favorite"] = False
                from socialfeatures.models import FavoriteTopic
                favoriteExist = FavoriteTopic.objects.filter(
                    topic=topic, enduser__id=enduser_id
                )
                if favoriteExist.count():
                    temp["is_favorite"] = True
                    temp["favorite_id"] = favoriteExist[0].id
                temp["active_status"] = topic.active_status
                created_at = topic.created_at+timedelta(hours=5,minutes=30)
                temp["created_at"] = created_at.strftime("%Y/%m/%d %I:%M %p")
                temp["updated_at"] = topic.updated_at.strftime("%Y/%m/%d %I:%M %p")

                if topic.enduser.id == enduser_id:
                    fcount = Follow.objects.filter(followee=topic.enduser.id)
                    temp["enduser"]["follower_count"] = fcount.count()
                else:
                    fcount = Follow.objects.filter(followee=topic.enduser.id)
                    temp["enduser"]["follower_count"] = fcount.count()

                    followExist = Follow.objects.filter(followee=topic.enduser.id, follower=enduser_id)
                    temp["enduser"]["is_followed"] = False
                    if followExist.count():
                        temp["enduser"]["is_followed"] = True
                        temp["enduser"]["follow_id"] = followExist[0].id
                temp["is_favorite"] = False
                from socialfeatures.models import FavoriteTopic
                favoriteExist = FavoriteTopic.objects.filter(
                    topic=topic, enduser__id=enduser_id
                )
                if favoriteExist.count():
                    temp["is_favorite"] = True
                    temp["favorite_id"] = favoriteExist[0].id
                    fav_count = FavoriteTopic.objects.filter(
                    topic=topic)
                    temp["favorite_count"] = fav_count.count()
                else:
                     temp["favorite_count"] = 0


                topic_count = TopicViews.objects.filter(
                    topic_id=topic.id)
                if topic_count.count() > 0:
                    temp["topic_view_count"] = topic_count.count()
                else:
                    temp["topic_view_count"] = 0
                final_data.append(temp)
            return Response(final_data, status=HTTP_200_OK)
        except Exception as e:
            return Response(
                {"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
            )


class TopicCountListing(ListAPIView):
    """
    Topic Count Listing GET API

        Service Usage and Description : This API is used to count all Topics with filters for area, genre or shop.
        Authentication Required : YES

        Params : {
            "shop"  :   "1",
            "area" : "1",
            "genre" : "1"
        }

        Response : {
            "success" : true,
            "count" : 1
        }
    """

    permission_classes = (IsAuthenticated, IsNotBanned | IsShopOwner | IsSuperAdmin)
    serializer_class = TopicSerializer

    def get_queryset(self):
        shop = self.request.GET.get("shop")
        area = self.request.GET.get("area")
        genre = self.request.GET.get("genre")
        queryset = Topic.objects.filter(active_status=True)
        if area != None:
            queryset = queryset.filter(area=area)
        if shop != None:
            queryset = queryset.filter(shop=shop)
        if genre != None:
            queryset = queryset.filter(genre=genre)
        return queryset

    def get(self, request):
        try:
            topics = self.get_queryset()
            return Response(
                {"success": True, "count": topics.count()}, status=HTTP_200_OK
            )
        except Exception as e:
            return Response(
                {"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
            )

class TopicPinnedDeleteHiddenCount(ListAPIView):
    """
    Topic Hidden,Deleted Listing GET API
        Usage : It Provides the Count of All pinned,hidden and Deleted Topics with filters for shop.
        Authentication Required : YES
        params : {
            "shop": "1"
        }
        Response : {
            "success" : true,
            "hidden_count" : 1,
            "delete_count" : 1,
            'pinned_count" : 1,
        }
    """
    permission_classes = (IsAuthenticated,IsNotBanned | IsShopOwner | IsSuperAdmin)
    serializer_class = TopicSerializer

    def get(self,request):
        try:
            hiddentopic = Topic.objects.filter(shop=self.request.GET.get("shop"),is_hidden=True)
            deletetopic = Topic.objects.filter(shop=self.request.GET.get("shop"),active_status=False)
            pinnedtopic = Topic.objects.filter(shop=self.request.GET.get("shop"),is_pinned_by_shop=True)
            return Response(
                {"sucess" : True,"hidden_count" : hiddentopic.count(),"delete_count" : deletetopic.count(),"pinned_count" : pinnedtopic.count()},status=HTTP_200_OK
            )
        except Exception as e:
            return Response(
                {"success": False,"message" : str(e)},status=HTTP_406_NOT_ACCEPTABLE
            )

class TopicUpdation(UpdateAPIView):
    """
    Topic Updation PUT API

        Service Usage and Description : This API is used to update Topic.
        Authentication Required : YES

        Data : {
            "id" : "1"
            "title" : "aasakfbkfbk"
        }

        Response : {
            "success": True,
            "message": "Topic Updated."
        }
    """

    permission_classes = (IsAuthenticated, IsSuperAdmin | IsShopOwner | IsNotBanned)
    serializer_class = TopicSerializer
    def put(self, request):
        try:
            data = request.data
            topic = Topic.objects.filter(id=data["id"])
            if topic.count() == 0:
                raise Exception("No Topic with given id.")
            serializer = TopicSerializer(topic[0], data=data, partial=True)
            if serializer.is_valid(raise_exception=True):
                serializer.save()
                return Response(
                    {"success": True, "message": "Topic Updated."},
                    status=HTTP_200_OK,
                )
        except Exception as e:
            return Response(
                {"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
            )


class TopicCommentCreation(CreateAPIView):
    """
    Topic Comment Creation POST API

        Service Usage and Description : This API is used to create Topic comment.
        Authentication Required : YES

        Data : {
            "user"  : "1" (This is the auth_user id, the field in enduser and shopowner, not the enduser id).
            "topic" : "1",
            "content" : "asdfghjk"
        }

        Response : {
            "data" : final_data
        }
    """

    permission_classes = (IsAuthenticated,)
    serializer_class = TopicCommentSerializer




class AllTopicCommentListing(ListAPIView):
    """
    All Topic Comment Listing GET API

        Service Usage and Description : This API is used to list all Topic comments.
        Authentication Required : YES

        Params : {
            "topic" : "1"
        }

        Response : {
            "data" : final_data
        }
    """

    permission_classes = (IsAuthenticated, IsNotBanned | IsShopOwner | IsSuperAdmin)
    serializer_class = TopicCommentSerializer

    def get_queryset(self):
        queryset = TopicComment.objects.filter(topic=self.request.GET.get("topic"))
        return queryset

    def get(self, request):
        try:
            queryset = self.get_queryset()
            final_data = []
            for topicComment in queryset:
                temp = {}
                temp["id"] = topicComment.id
                temp["content"] = topicComment.content
                temp["created_at"] = topicComment.created_at
                temp["updated_at"] = topicComment.updated_at
                enduser = EndUser.objects.filter(auth_user=topicComment.user)
                if enduser.count():
                    temp["enduser"] = {}
                    temp["enduser"]["id"] = enduser[0].id
                    temp["enduser"]["name"] = enduser[0].name
                    temp["enduser"]["username"] = enduser[0].auth_user.username
                    temp["enduser"]["avatar"] = enduser[0].avatar
                    temp["is_shopowner"] = False
                shopowner = ShopOwner.objects.filter(auth_user=topicComment.user)
                if shopowner.count():
                    temp["shopowner"] = {}
                    temp["shopowner"]["id"] = shopowner[0].id
                    temp["shopowner"]["name"] = shopowner[0].name
                    temp["shopowner"]["username"] = shopowner[0].auth_user.username
                    temp["shopowner"]["avatar"] = None
                    if shopowner[0].photo:
                        temp["shopowner"]["avatar"] = shopowner[0].photo
                    temp["is_shopowner"] = True
                final_data.append(temp)
            return Response(final_data, status=HTTP_200_OK)
        except Exception as e:
            return Response(
                {"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
            )


# class TopicCommentUpdation(UpdateAPIView):
#     """
#     Topic Comment Updation PUT API

#       Service Usage and Description : This API is used to update Topic comment.
#       Authentication Required : YES

#       Data : {
#           "id" : "1",
#           "content": "ABC"
#       }

#       Response : {
#           "success": True,
#           "message": "Topic Comment Updated."
#       }
#     """

#     permission_classes = (IsAuthenticated, IsShopOwner)
#     serializer_class = TopicCommentSerializer

#     def put(self, request):
#         try:
#             data = request.data
#             TopicComment = TopicComment.objects.filter(id=data["id"])
#             if Topiccomment.count() == 0:
#                 raise Exception("No Topic Comment with given id.")
#             serializer = TopicCommentSerializer(
#                 TopicComment[0], data=data, partial=True
#             )
#             if serializer.is_valid(raise_exception=True):
#                 serializer.save()
#                 return Response(
#                     {"success": True, "message": "Topic Comment Updated."},
#                     status=HTTP_200_OK,
#                 )
#         except Exception as e:
#             return Response(
#                 {"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
#             )


class TopicCommentDeletion(DestroyAPIView):
    """
    Topic Comment Deletion DELETE API

        Service Usage and Description : This API is used to delete Topic comment.
        Authentication Required : YES

        Data : {
            "id" : "1"
        }

        Response : {
            "success" : True,
            "message" : "Topic Comment Deleted."
        }
    """

    permission_classes = (IsAuthenticated, IsNotBanned | IsShopOwner | IsSuperAdmin)
    serializer_class = TopicCommentSerializer

    def get_queryset(self):
        queryset = TopicComment.objects.filter(id=self.request.data["id"])
        return queryset

    def delete(self, request):
        try:
            topicComment = self.get_queryset()
            if topicComment.count() == 0:
                raise Exception("No Topic Comment with given id.")
            self.perform_destroy(topicComment)
            return Response(
                {"success": True, "message": "Topic Comment Deleted."},
                status=HTTP_200_OK,
            )
        except Exception as e:
            return Response(
                {"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
            )


class TopicLikeCreation(CreateAPIView):
    """
    Topic Like Creation POST API

        Service Usage and Description : This API is used to create Topic like.
        Authentication Required : YES

        Data : {
            "topic" : "1",
            "enduser" : "1"
        }

        Response : {
            "data" : final_data
        }
    """

    permission_classes = (IsAuthenticated, IsNotBanned)
    serializer_class = TopicLikeSerializer


class TopicLikeListing(ListAPIView):
    """
    All Topic Like Listing GET API

        Service Usage and Description : This API is used to list Topic like by an end user.
        Authentication Required : YES

        Params : {
            "topic" : "1",
            "enduser" : "1"
        }

        Response : {
            "data" : final_data
        }
    """

    permission_classes = (IsAuthenticated, IsNotBanned | IsShopOwner | IsSuperAdmin)
    serializer_class = TopicLikeSerializer

    def get_queryset(self):
        queryset = TopicLike.objects.filter(
            topic=self.request.GET.get("topic"), enduser=self.request.GET.get("enduser")
        )
        return queryset


class TopicLikeCountListing(ListAPIView):
    """
    Topic Like Count Listing GET API

        Service Usage and Description : This API is used to count all likes for a Topic.
        Authentication Required : YES

        Params : {
            "topic" :   "1"
        }

        Response : {
            "success" : true,
            "count" : 1
        }
    """

    permission_classes = (IsAuthenticated, IsNotBanned | IsShopOwner | IsSuperAdmin)
    serializer_class = TopicLikeSerializer

    def get(self, request):
        try:
            topicLikes = TopicLike.objects.filter(topic=self.request.GET.get("topic"))
            return Response(
                {"success": True, "count": topicLikes.count()}, status=HTTP_200_OK
            )
        except Exception as e:
            return Response(
                {"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
            )


class TopicLikeDeletion(DestroyAPIView):
    """
    Topic Like Deletion DELETE API

        Service Usage and Description : This API is used to delete Topic like.
        Authentication Required : YES

        Data : {
            "id" : "1"
        }

        Response : {
            "success" : True,
            "message" : "Topic Like Deleted."
        }
    """

    permission_classes = (IsAuthenticated, IsNotBanned)
    serializer_class = TopicLikeSerializer

    def get_queryset(self):
        queryset = TopicLike.objects.filter(id=self.request.data["id"])
        return queryset

    def delete(self, request):
        try:
            topicLike = self.get_queryset()
            if topicLike.count() == 0:
                raise Exception("No Topic Like with given id.")
            self.perform_destroy(topicLike)
            return Response(
                {"success": True, "message": "Topic Like Deleted."},
                status=HTTP_200_OK,
            )
        except Exception as e:
            return Response(
                {"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
            )





class LatestTopic(ListAPIView):
    """
    Latest Topic Listing GET API

        Service Usage and Description : This API is used to list latest Topics.
        Authentication Required : YES

        Params : {

        }

        Response : {
            "data" : final_data
        }
    """

    permission_classes = (IsAuthenticated, IsSuperAdmin)
    serializer_class = TopicSerializer

    def get_queryset(self):
        queryset = Topic.objects.filter(active_status=True)
        return queryset

class TopicListData(ListAPIView):
    """
    Topic List GET API
      Params:  {
            "page_no": 1,
            "page_size": 10,
        }
        Service usage and description : This API is used to list topics.
        Authentication Required : YES
    """

    permission_classes = (
        IsAuthenticated, IsSuperAdmin
    )
    serializer_class = TopicSerializer
    queryset = Topic.objects.all()

    def get(self, request):
        try:
            p_no= self.request.GET.get("page_no")
            p_size = self.request.GET.get("page_size")
            page_no = 1
            page_size = 10
            topic_data = Topic.objects.filter()
            if p_no != None:
                page_no = int(self.request.GET.get("page_no"))
            if p_size != None:
                page_size = int(self.request.GET.get("page_size"))
            try:
                if page_size > 200:
                    page_size = 200
                pages = Paginator(topic_data, page_size)
                topic_c_data = pages.page(page_no)
            except PageNotAnInteger:
                page_no = 1
                topic_c_data = pages.page(page_no)
            except EmptyPage:
                page_no = pages.num_pages
                topic_c_data = pages.page(page_no)
            page_count = pages.count
            page_info = {
                "page_no": page_no,
                "page_size": page_size,
                "total_topics": page_count,
                "total_pages" : pages.num_pages
            }
            final_data = []
            for index in range(len(topic_c_data.object_list)):
                p_list ={}
                p_list['id'] = topic_c_data[index].id
                p_list['title'] = topic_c_data[index].title
                p_list['content'] = topic_c_data[index].content
                p_list['area'] =  topic_c_data[index].area.name if topic_c_data[index].area else ''
                p_list['active_status'] = topic_c_data[index].active_status
                final_data.append(p_list)
            return Response(
                {"success": True, 
                "data": final_data,
                "page": page_info}, status=HTTP_200_OK
            )
        except Exception as e:
            return Response(
                {"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
            )


class TopicReasonListAPI(ListAPIView):
    """
    Topic Delete Reason List Get API

        Params:  {
            "page_no": 1,
            "page_size": 10,
        }
        Service usage and description : This API is used to list topics.
        Authentication Required : YES
    """

    permission_classes = (
        IsAuthenticated, IsSuperAdmin
    )
    serializer_class = TopicDeleteSerializer
    queryset = TopicDeleteReason.objects.all()

    def get(self, request):
        try:
            p_no= self.request.GET.get("page_no")
            p_size = self.request.GET.get("page_size")
            page_no = 1
            page_size = 10
            topic_data = TopicDeleteReason.objects.filter(active_status=True)
            if p_no != None:
                page_no = int(self.request.GET.get("page_no"))
            if p_size != None:
                page_size = int(self.request.GET.get("page_size"))
            try:
                if page_size > 200:
                    page_size = 200
                pages = Paginator(topic_data, page_size)
                topic_d_data = pages.page(page_no)
            except PageNotAnInteger:
                page_no = 1
                topic_d_data = pages.page(page_no)
            except EmptyPage:
                page_no = pages.num_pages
                topic_d_data = pages.page(page_no)
            page_count = pages.count
            page_info = {
                "page_no": page_no,
                "page_size": page_size,
                "total_topics": page_count,
                "total_pages" : pages.num_pages
            }
            final_data = []
            for index in range(len(topic_d_data.object_list)):
                p_list ={}
                p_list['id'] = topic_d_data[index].id
                p_list['topic ID'] = topic_d_data[index].topic.id
                p_list['shop ID'] = topic_d_data[index].shop.id
                p_list['reason'] =  topic_d_data[index].reason
                final_data.append(p_list)
            return Response(
                {"success": True, 
                "data": final_data,
                "page": page_info}, status=HTTP_200_OK
            )
        except Exception as e:
            return Response(
                {"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
            )