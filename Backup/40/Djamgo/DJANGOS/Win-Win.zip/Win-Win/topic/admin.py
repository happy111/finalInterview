from django.contrib import admin
from .models import *

admin.site.register(Topic)
admin.site.register(TopicComment)
admin.site.register(TopicLike)
admin.site.register(TopicDeleteReason)
