from django.db import models
from area.models import *
from genre.models import *
from shops.models import *
from users.models import *
from django.contrib.auth.models import User
from django.contrib.postgres.fields import ArrayField


class Topic(models.Model):
    enduser = models.ForeignKey(
        EndUser,
        related_name="topic_enduser",
        on_delete=models.CASCADE,
        verbose_name="Topic Posted By ",
    )
    area = models.ForeignKey(
        Area,
        null=True,
        blank=True,
        related_name="topic_area",
        on_delete=models.CASCADE,
        verbose_name="Topic Area",
    )
    city = models.ForeignKey(
        City,
        null=True,
        blank=True,
        related_name="topic_city",
        on_delete=models.CASCADE,
        verbose_name="Topic City",
    )

    hashtags = ArrayField(
        models.TextField(),
        null=True, 
        blank=True,\
        verbose_name="Hashtags")


    genre = models.ForeignKey(
        Genre,
        null=True,
        blank=True,
        related_name="topic_genre",
        on_delete=models.CASCADE,
        verbose_name="Topic Genre",
    )
    title = models.CharField(
        max_length=100, 
        verbose_name="Topic Title")
    content = models.CharField(
        max_length=1000, 
        verbose_name="Topic Content")
    url = models.CharField(
        max_length=100, 
        verbose_name="Url",
        null=True,
        blank=True,
        )

    remark = models.CharField(
        max_length=100, 
        verbose_name="Remark",
        null=True,
        blank=True,
        )

    shop = models.ForeignKey(
        Shop,
        related_name="topic_shop",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        verbose_name="Topic Tagged Shop",
    )
    views_count = models.PositiveIntegerField(
        default=0, null=True, blank=True, verbose_name="View Count"
    )
    is_pinned_by_user = models.BooleanField(
        default=0, null=True, blank=True, verbose_name="Is Topic Pinned By User"
    )
    is_pinned_by_shop = models.BooleanField(
        default=0, null=True, blank=True, verbose_name="Is Topic Pinned By Shop"
    )
    active_status = models.BooleanField(
        default=1, null=True, blank=True, verbose_name="Topic Active Status"
    )
    is_hidden = models.BooleanField(
        default=0, null=True, blank=True, verbose_name="Is Topic Hidden"
    )
    is_report = models.BooleanField(
        default=0, null=True, blank=True, verbose_name="Is Reported"
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        editable=False,
        null=True,
        blank=True,
        verbose_name="Creation Date & Time",
    )
    updated_at = models.DateTimeField(
        auto_now=True, null=True, blank=True, verbose_name="Updation Date & Time"
    )
    expiry_date = models.DateTimeField(
        null=True, blank=True, verbose_name="Expire Date"
    )

    class Meta:
        verbose_name = "Topic"
        verbose_name_plural = "Topics"

    def __str__(self):
        return self.title


class TopicLike(models.Model):
    topic = models.ForeignKey(
        Topic,
        related_name="topiclike_topic",
        on_delete=models.CASCADE,
        verbose_name="Topic",
    )
    enduser = models.ForeignKey(
        EndUser,
        related_name="topiclike_enduser",
        on_delete=models.CASCADE,
        verbose_name="Topic Liked By",
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        editable=False,
        null=True,
        blank=True,
        verbose_name="Creation Date & Time",
    )

    class Meta:
        verbose_name = "Topic Like"
        verbose_name_plural = "Topic Likes"


class TopicComment(models.Model):
    topic = models.ForeignKey(
        Topic,
        related_name="topiccomment_topic",
        on_delete=models.CASCADE,
        verbose_name="Topic",
    )
    user = models.ForeignKey(
        User,
        related_name="topiccomment_user",
        on_delete=models.CASCADE,
        verbose_name="Topic Comment Posted By",
    )
    content = models.CharField(max_length=200, verbose_name="Topic Content")
    created_at = models.DateTimeField(
        auto_now_add=True,
        editable=False,
        null=True,
        blank=True,
        verbose_name="Creation Date & Time",
    )
    updated_at = models.DateTimeField(
        auto_now=True, null=True, blank=True, verbose_name="Updation Date & Time"
    )

    class Meta:
        verbose_name = "Topic Comment"
        verbose_name_plural = "Topic Comments"

    def __str__(self):
        return self.topic.title + ", " + self.user.username

class TopicDeleteReason(models.Model):
    topic = models.ForeignKey(
        Topic,
        related_name="topicreason_topic",
        on_delete=models.CASCADE,
        verbose_name="Topic",
    )
    reason = models.CharField(max_length=200, verbose_name="Topic Delete Content")
    shop = models.ForeignKey(
        Shop,
        related_name="topic_delete_shop",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        verbose_name="Topic Delete Shop",
    )

    active_status = models.BooleanField(
        default=1, null=True, blank=True, verbose_name="Topic Active Status"
    )
    
    class Meta:
        verbose_name = "Topic Delete"
        verbose_name_plural = "Topic Delete"

    def __str__(self):
        return self.topic.title + ", " + self.shop.name