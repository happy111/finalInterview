from django.urls import path
from .views import *

urlpatterns = [
    path("create/", TopicCreation.as_view()),
    path("active-listing/", ActiveTopicListing.as_view()),
    path("all-listing/",AllTopicListing.as_view()),
    path("id-listing/", TopicDataListing.as_view()),
    path("count-listing/", TopicCountListing.as_view()),
    path("update/", TopicUpdation.as_view()),
    path("comment-create/", TopicCommentCreation.as_view()),
    path("comment-listing/", AllTopicCommentListing.as_view()),
    path("comment-delete/", TopicCommentDeletion.as_view()),
    path("like-create/", TopicLikeCreation.as_view()),
    path("like-listing/", TopicLikeListing.as_view()),
    path("like-count-listing/", TopicLikeCountListing.as_view()),
    path("like-delete/", TopicLikeDeletion.as_view()),
    path("alllist/",TopicListData.as_view()),
    path("delete/<pk>/",TopicDeleteAPI.as_view()),

  #  path("latest/topic/", LatestTopic.as_view()),

    path('count-hidden-deleted-pinned/',TopicPinnedDeleteHiddenCount.as_view()),
    path("latest/topic/", LatestTopic.as_view()),
    path("cancel-request/",TopicCancellatonRequest.as_view()),
    path("delete-approval/<pk>/",TopicReasonDeleteAPI.as_view()),
    path("delete-approval-list/",TopicReasonListAPI.as_view())
]


