from django.shortcuts import render
from .models import *
from .serializers import *
from rest_framework.views import APIView
from rest_framework.generics import (
    CreateAPIView,
    ListAPIView,
    DestroyAPIView,
    UpdateAPIView,
    RetrieveAPIView,
)
from rest_framework.permissions import IsAuthenticated
from django.contrib.auth.models import User

# from django.contrib.auth.decorators import login_required
from rest_framework.authtoken.models import Token
from winwin.permissions import IsShopOwner, IsNotBanned
from django.contrib.auth import authenticate, login
from rest_framework.response import Response
from rest_framework.status import (
    HTTP_200_OK,
    HTTP_406_NOT_ACCEPTABLE,
    HTTP_401_UNAUTHORIZED,
)
import requests, json
from requests_oauthlib import OAuth1
from winwin.settings import SOCIAL_AUTH_TWITTER_KEY, SOCIAL_AUTH_TWITTER_SECRET
import random, string






class SuperUserCreateLogin(APIView):
    """
    Shop Owner Login Post API

        Service Usage and Description : Login View for shops owner.

        Data: {
            username: "myusername",
            password: "password"
        }
        Response: {
            "success": True,
            "message": "You are logged in now!!",
            "token": token.key,
            "shop" : "1"
        }
    """


    def post(self, request):
        try:
            data = request.data
            serializer = UserLoginSerializer(data=data)
            if serializer.is_valid(raise_exception=True):
                user = authenticate(
                    username=data["username"], password=data["password"]
                )
                if not (user and user.is_active and user.is_superuser):
                    raise Exception("No User exists for the given credentials.")
                else:
                    if user and user.is_active == True:
                        token, created = Token.objects.get_or_create(user=user)
                        return Response(
                            {
                                "success": True,
                                "message": "You are logged in now!!",
                                "token": token.key,
                            },
                            status=HTTP_200_OK,
                        )
        except Exception as e:
            return Response({"message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE)


class SuperUserLogout(APIView):
    """
    Super user Logout Post API

        Service Usage and Description : Logout view for Super user logout.
        Authentication token required:    Yes

        Response : {
            "success": True,
            "message": "You are logged out now!!",
            }
    """

    permission_classes = (IsAuthenticated,)
    def post(self, request):
        try:
            request.user.auth_token.delete()
            return Response(
                {
                    "success": True,
                    "message": "You are logged out now!!",
                },
                status=HTTP_200_OK,
            )
        except Exception as e:
            return Response(
                {"success": False, "message": str(e)},
                status=HTTP_401_UNAUTHORIZED,
            )

