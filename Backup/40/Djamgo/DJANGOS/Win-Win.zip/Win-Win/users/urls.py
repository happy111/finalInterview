from django.urls import path
from .views import *
from .superView import *
from .shopView import *


urlpatterns = [
    # path("endusercreate/", EndUserCreation.as_view()),
    path("enduserlogin/", EndUserCreateLogin.as_view()),
    path("enduserlogout/", EndUserLogout.as_view()),
    path("enduser/<int:pk>/", EndUserRetrieval.as_view()),
    path("shopownerlogin/", ShopOwnerLogin.as_view()),
    path("shopownerlogout/", ShopOwnerLogout.as_view()),
    path("shopownerupdate/", ShopOwnerUpdate.as_view()),
    path("shopowner/<int:pk>/", ShopOwnerRetrieval.as_view()),
    path("enduser/update/", UserUpdation.as_view()),
    path("enduser/favorite/", FavoriteData.as_view()),
    path("enduser/alllist/", EnduserListData.as_view()),
    path("enduser/search/", SearchData.as_view()),


    # SuperAdmin Api
    path("superuser/login/", SuperUserCreateLogin.as_view()),
    path("superuser/logout/", SuperUserLogout.as_view()),
    path("superuser/monthly/report/", SuperUserReport.as_view()),


    #
    path("shopowner/create/", ShopCreateOwner.as_view()),
   # path("superuser/create/", ShopCreateOwner.as_view()),
    path("shop-shopowner/create/",shopOwnerShopCreateAPI.as_view()),
    path("shop-shopowner/update/",shopOwnerShopUpdateAPI.as_view()),
    path("shopowner/monthly/report/", ShopReport.as_view()),
    path("shopowner/alllist/",ShopOwnerListData.as_view())

]
