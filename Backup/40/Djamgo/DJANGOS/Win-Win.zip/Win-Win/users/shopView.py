from django.shortcuts import render
from .models import *
from .serializers import *
from rest_framework.views import APIView
from rest_framework.generics import (
    CreateAPIView,
    ListAPIView,
    DestroyAPIView,
    UpdateAPIView,
    RetrieveAPIView,
)
from rest_framework.permissions import IsAuthenticated
from django.contrib.auth.models import User

# from django.contrib.auth.decorators import login_required
from rest_framework.authtoken.models import Token
from winwin.permissions import IsShopOwner, IsNotBanned, IsSuperAdmin
from django.contrib.auth import authenticate, login
from rest_framework.response import Response
from rest_framework.status import (
    HTTP_200_OK,
    HTTP_406_NOT_ACCEPTABLE,
    HTTP_401_UNAUTHORIZED,
)
import requests, json
from requests_oauthlib import OAuth1
from winwin.settings import SOCIAL_AUTH_TWITTER_KEY, SOCIAL_AUTH_TWITTER_SECRET
import random, string
from users.serializers import ShopOwnerSerializer,UserSerializer
from shops.serializers import ShopSerializer


class ShopCreateOwner(CreateAPIView):
    """
    Creation Shop User API

        Service Usage and Description: This API is used to create Shop ownder.
        Authentication Required: NO

        Data : {
        }

        Response : {
            "success":true,
            "message":"User Creation/Updation and Login Successful.",
            "token":"0d0234873915e52345a16cf7f861134acd7b2bcb",
            "enduser":3
        }
    """

    serializer_class = EndUserSerializer

    def post(self, request):
        try:
            data = request.data
            user_exist = User.objects.filter(username=data['username'])
            if user_exist.count() > 0:
                raise Exception("User Already exist!!")
            else:
                create_user = User.objects.create_user(
                username=data['username'],
                email=data['email'],
                password=data["password"],
                is_staff=False,
                is_active=True,
            )
            if create_user:
                registration_data = {}
                registration_data["auth_user"] = create_user.id
                registration_data["shop"] = data['shop']
                registration_data["name"] = data['name']
                serializer = ShopOwnerSerializer(data=registration_data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(
                        {
                            "success": True,
                            "message": "ShopOwnder Created Successful.",
                            
                        },
                        status=HTTP_200_OK,
                    )
                else:
                    print("sssssssssssss",serializer.errors)
        except Exception as e:
            return Response(
                {"success": False, "message": str(e)},
                status=HTTP_401_UNAUTHORIZED,
            )

class shopOwnerShopCreateAPI(APIView):
    """
    Creation Shop Owner and Shop API

        Service Usage and Description: This API is used to create Shop owner and shop by superadmin.
        Authentication Required: YES

        Data : {
            "genre" : 1,
            "shop_name" : "Agarwal Sweets",
            "city" : 1,
            "shop_url" : "www.xyz.com",
            "shop_address" : "B.H Estate",
            "opening_time" : "9:00",
            "closing_time" : "18:00",
            "shop_phone_number" : "+917979797979",
            "name" : "Jatin", 
            "email" : "jatin@eoraa.com",
            "password" : "J007",
            "plan" : true,
            "comment" : "First SHop"
        }

        Response : {
            "success":true,
            "message":"ShopOwner and Shop Created Successful.",
        }
    """

    permission_classes = (IsAuthenticated, IsSuperAdmin)

    def post(self, request):
        try:
            data = request.data
            user_exist = User.objects.filter(username=data['name'])
            if user_exist.count() > 0:
                raise Exception("User Already exist!!")
            else:
                print("eeee")
                create_user = User.objects.create_user(
                username=data['name'],
                email=data['email'],
                password=data["password"],
                is_staff=False,
                is_active=True,
            )
            if create_user:
                registration_data = {}
                shop_data = {}
                shop_data["genre"] = data["genre"]
                shop_data["name"] = data["shop_name"]
                shop_data["city"] = data["city"]
                shop_data["url"] = data["shop_url"]
                shop_data["address"] = data["shop_address"]
                shop_data["opening_time"] = data["opening_time"]
                shop_data["closing_time"] = data["closing_time"]
                shop_data["phone_number"] = data["shop_phone_number"]
                shop_data["is_premium"] = data["plan"]
                shop_data["comment"] = data["comment"]
                serializer = ShopSerializer(data=shop_data)
                if serializer.is_valid():
                    shop = serializer.save()
                    print(shop.id)
                registration_data["shop"] = shop.id
                registration_data["auth_user"] = create_user.id
                registration_data["name"] = data['name']
                registration_data["email"] = data['email']
                serializer2 = ShopOwnerSerializer(data=registration_data)
                if serializer2.is_valid():
                    serializer2.save()
                    return Response(
                        {
                            "success": True,
                            "message": "ShopOwner and Shop Created Successful.",
                            
                        },
                        status=HTTP_200_OK,
                    )
                else:
                    print("Errors:",serializer.errors)


        except Exception as e:
            return Response(
                {"success": False, "message": str(e)},
                status=HTTP_401_UNAUTHORIZED,
            )

class shopOwnerShopUpdateAPI(APIView):
    """
    Updation of Shop and SHopOwner

        Usage : Update Shop and Shop Owner
        Authentication Required: YES

    Data : {
            "id" : 1
            "genre" : 1,
            "shop_name" : "Agarwal Sweets",
            "city" : 1,
            "shop_url" : "www.xyz.com",
            "shop_address" : "B.H Estate",
            "opening_time" : "9:00",
            "closing_time" : "18:00",
            "shop_phone_number" : "+917979797979",
            "name" : "Jatin", 
            "email" : "jatin@eoraa.com",
            "password" : "J007",
            "plan" : true,
            "comment" : "First SHop"
        }

    """
    permission_classes = (IsAuthenticated, IsSuperAdmin)

    def put(self, request):
        try:
            data = request.data
            shopowner = ShopOwner.objects.filter(id=data["id"])
            check_the_user = User.objects.filter(id=shopowner[0].auth_user.id).first()
            shop = Shop.objects.filter(id=shopowner[0].shop.id)
            if shopowner.count() == 0:
                raise Exception("No ShopOwner with given id.")
            registration_data = {}
            shop_data = {}
            user_data = {}
            shop_data["genre"] = data["genre"]
            shop_data["name"] = data["shop_name"]
            shop_data["city"] = data["city"]
            shop_data["url"] = data["shop_url"]
            shop_data["address"] = data["shop_address"]
            shop_data["opening_time"] = data["opening_time"]
            shop_data["closing_time"] = data["closing_time"]
            shop_data["phone_number"] = data["shop_phone_number"]
            shop_data["is_premium"] = data["plan"]
            shop_data["comment"] = data["comment"]
            serializer = ShopSerializer(shop[0], data=shop_data, partial=True)
            registration_data["name"] = data['name']
            registration_data["email"] = data['email']
            serializer2 = ShopOwnerSerializer(shopowner[0],data = registration_data,partial=True)
            user_data["username"] = data['name']
            user_data["email"] = data["email"]
            # user_data["password"] = data['password']
            serializer3 = UserSerializer(check_the_user,data = user_data,partial=True)
            if serializer.is_valid(raise_exception=True) and serializer2.is_valid(raise_exception=True) and serializer3.is_valid(raise_exception = True):
                serializer.save()
                serializer2.save()
                serializer3.save()
                if "password" in data:
                    if data["password"] != None:
                        check_the_user.set_password(data["password"])
                        check_the_user.save()
                return Response(
                    {"success": True, "message": "Shop and ShopOwner Updated."},
                    status=HTTP_200_OK,
                )
        except Exception as e:
            return Response(
                {"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
            )
