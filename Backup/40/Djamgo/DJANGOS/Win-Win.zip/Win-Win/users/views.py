from django.shortcuts import render
from .models import *
from .serializers import *
from rest_framework.views import APIView
from rest_framework.generics import (
	CreateAPIView,
	ListAPIView,
	DestroyAPIView,
	UpdateAPIView,
	RetrieveAPIView,
)
from rest_framework.permissions import IsAuthenticated
from django.contrib.auth.models import User

# from django.contrib.auth.decorators import login_required
from rest_framework.authtoken.models import Token
from winwin.permissions import IsShopOwner, IsNotBanned,IsSuperAdmin
from django.contrib.auth import authenticate, login
from rest_framework.response import Response
from rest_framework.status import (
	HTTP_200_OK,
	HTTP_406_NOT_ACCEPTABLE,
	HTTP_401_UNAUTHORIZED,
)
import requests, json
from requests_oauthlib import OAuth1
from winwin.settings import SOCIAL_AUTH_TWITTER_KEY, SOCIAL_AUTH_TWITTER_SECRET
import random, string
from socialfeatures.serializers import *
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from topic.models import TopicLike,TopicComment
from socialfeatures.models import FavoriteTopic,FavoriteShop
from review.serializers import *



class EndUserCreateLogin(CreateAPIView):
	"""
	End User Creation/Login API

		Service Usage and Description: This API is used to create/update a user from twitter callback and generate an auth token.
		Authentication Required: NO

		Data : {
			callback data from twitter
		}

		Response : {
			"success":true,
			"message":"User Creation/Updation and Login Successful.",
			"token":"0d0234873915e52345a16cf7f861134acd7b2bcb",
			"enduser":3
		}
	"""

	serializer_class = EndUserSerializer
	def post(self, request):
		try:
			data = request.data
			username = data["screenName"]
			password = "".join(
				random.choices(string.ascii_uppercase + string.digits, k=8)
			)
			user_exist = User.objects.filter(username=username)
			if user_exist.count() == 0:
				user_exist = User.objects.create_user(
					username=username, password=password
				)
			else:
				user_exist = user_exist.first()
			enduser = EndUser.objects.filter(auth_user=user_exist.id)
			validated_data = {}
			
			if enduser.count() == 0:
				validated_data["auth_user"] = user_exist.id
				validated_data["name"] =  data["displayName"]
				validated_data["avatar"] = data['providerUserInfo'][0]['photoUrl']
				serializer = EndUserSerializer(data=validated_data)
				if serializer.is_valid(raise_exception=True):
					enduser = serializer.save()
			else:
				validated_data["auth_user"] = user_exist.id
				validated_data["avatar"] = data['providerUserInfo'][0]['photoUrl']
				serializer = EndUserSerializer(enduser[0], data=validated_data)
				if serializer.is_valid(raise_exception=True):
					enduser = serializer.save()
			if (
				enduser.is_banned == False
				and enduser.active_status
				and user_exist.is_active
			):
				token, created = Token.objects.get_or_create(user=user_exist)
				return Response(
					{
						"success": True,
						"message": "User Creation/Updation and Login Successful.",
						"token": token.key,
						"enduser": enduser.id,
						"area"   : enduser.area_id
						
					},
					status=HTTP_200_OK,
				)
		except Exception as e:
			return Response(
				{"success": False, "message": str(e)},
				status=HTTP_401_UNAUTHORIZED,
			)


class EndUserRetrieval(RetrieveAPIView):
	"""
	End User Data Retrieval API

		Service Usage andd Description : This API is used to retrieve profile data of an enduser.
		Authentication Required: YES
	"""

	permission_classes = (IsAuthenticated, IsShopOwner | IsNotBanned)
	serializer_class = EndUserSerializer
	queryset = EndUser.objects.all()

	def retrieve(self, request, *args, **kwargs):
		from topic.models import Topic
		from review.models import Review
		from socialfeatures.models import Follow

		instance = self.get_object()
		serializer = self.get_serializer(instance)
		data = serializer.data
		user = request.user
		enduser = EndUser.objects.filter(auth_user=user)
		enduser_id = None
		if enduser.count():
			enduser_id = enduser[0].id
		data["topic_count"] = Topic.objects.filter(enduser=data["id"]).count()
		data["review_count"] = Review.objects.filter(enduser=data["id"]).count()
		
		data["followee_count"] = Follow.objects.filter(follower=data["id"]).count()
		data["follower_count"] = Follow.objects.filter(followee=data["id"]).count()
		data["profile_count"] = ProfileView.objects.filter(profile=data["id"]).count()

		followExist = Follow.objects.filter(followee=data["id"], follower=enduser_id)
		data["is_followed"] = False
		if followExist.count():
			data["is_followed"] = True
			data["follow_id"] = followExist[0].id
		return Response(data)


class EndUserLogout(APIView):
	"""
	End User Logout Post API

		Authentication Required:    Yes
		Service Usage and Description : Logout view for end users.

		Response :
		{
			"success": True,
			"message": "You are logged out now!!",
		}
	"""

	permission_classes = (IsAuthenticated, IsNotBanned)

	def post(self, request):
		user = request.user
		request.user.auth_token.delete()
		return Response(
			{
				"success": True,
				"message": "You are logged out now!!",
			},
			status=HTTP_200_OK,
		)


class ShopOwnerLogin(APIView):
	"""
	Shop Owner Login Post API

		Service Usage and Description : Login View for shops owner.

		Data: {
			username: "myusername",
			password: "password"
		}
		Response: {
			"success": True,
			"message": "You are logged in now!!",
			"token": token.key,
			"shop" : "1"
		}
	"""

	# permission_classes = (IsShopOwner,)

	def post(self, request):
		try:
			data = request.data
			serializer = UserLoginSerializer(data=data)
			if serializer.is_valid(raise_exception=True):
				user = authenticate(
					username=data["username"], password=data["password"]
				)
				shopowner = ShopOwner.objects.filter(auth_user=user)
				if shopowner.count() == 0:
					raise Exception("No Shop Owner with given credentials.")
				if user and user.is_active == True:
					token, created = Token.objects.get_or_create(user=user)
					return Response(
						{
							"success": True,
							"message": "You are logged in now!!",
							"token": token.key,
							"shopowner": shopowner[0].shop.id,
						},
						status=HTTP_200_OK,
					)
		except Exception as e:
			return Response(
				{"success": False, "message": str(e)},
				status=HTTP_401_UNAUTHORIZED,
			)


class ShopOwnerLogout(APIView):
	"""
	Shop Owner Logout Post API

		Service Usage and Description : Logout view for Shops Owner.
		Authentication token required:    Yes

		Response : {
			"success": True,
			"message": "You are logged out now!!",
			}
	"""

	permission_classes = (IsAuthenticated, IsShopOwner)

	def post(self, request):
		try:
			request.user.auth_token.delete()
			return Response(
				{
					"success": True,
					"message": "You are logged out now!!",
				},
				status=HTTP_200_OK,
			)
		except Exception as e:
			return Response(
				{"success": False, "message": str(e)},
				status=HTTP_401_UNAUTHORIZED,
			)


class ShopOwnerUpdate(UpdateAPIView):
	"""
	Shop Owner Update API.
		Service Usage and Description : This API is used to update the shop owner details.
		Authentication token required:    Yes
		Data : {
			"username": "abcdefgh",
			"password": "qwertyui",
		}
		Response : {
			"success": True,
			"message": "Shop Owner Profile Updated.",
		}
	"""

	permission_classes = (IsAuthenticated, IsShopOwner)
	serializer_class = ShopOwnerSerializer

	def put(self, request):
		try:
			data = request.data
			user = request.user
			check_the_user = User.objects.filter(id=user.id).first()
			user_serializer = UserSerializer(data=data, partial=True)
			if user_serializer.is_valid(raise_exception=True):
				shopowner_serializer = ShopOwnerSerializer(data=data, partial=True)
				if shopowner_serializer.is_valid(raise_exception=True):
					user_serializer.save()
					shopowner_serializer.save()
					if "password" in data:
						check_the_user.set_password(data["password"])
						check_the_user.save()
					return Response(
						{"success": True, "message": "Shop Owner Profile Updated."},
						status=HTTP_200_OK,
					)
		except Exception as e:
			return Response(
				{"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
			)


class ShopOwnerRetrieval(RetrieveAPIView):
	"""
	Shop Owner Data Retrieval API

		Service Usage andd Description : This API is used to retrieve profile data of a shop owner.
		Authentication Required: YES
	"""

	permission_classes = (IsAuthenticated, IsShopOwner | IsNotBanned)
	serializer_class = ShopOwnerDataSerializer
	queryset = ShopOwner.objects.all()





class UserUpdation(UpdateAPIView):
	"""
	User Updation PUT API

		Service Usage and Description : This API is used to update user.
		Authentication Required : YES

		Data : {
			"id"          : "1",
			"display_name"        : "",
			"description" : ""

		}

		Response : {
			"success": True,
			"message": "User Updated."
		}
	"""

	permission_classes = (IsAuthenticated,)
	serializer_class = EndUserSerializer

	def put(self, request):
		try:
			data = request.data
			user_data = EndUser.objects.filter(id=data["id"])
			if user_data.count() == 0:
				raise Exception("No User with given id.")
			serializer = EndUserSerializer(user_data[0], data=data, partial=True)
			if serializer.is_valid(raise_exception=True):
				serializer.save()
				return Response(
					{"success": True, "message": "Profile updated successfully!"},
					status=HTTP_200_OK,
				)
		except Exception as e:
			return Response(
				{"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
			)







class FavoriteData(ListAPIView):

	"""
	Favorite Topic Listing GET API

		Service Usage and Description : This API is used to list active topic which a user has favorite relationship with.
		Authentication Required : YES

		Params : {
			"enduser" : "2"
		}

		Response : {
			final_data(list of json)
		}
	"""

	permission_classes = (IsAuthenticated, IsNotBanned)
	serializer_class = FavoriteTopicDataSerializer

	def get(self,request):
		queryset = FavoriteTopic.objects.filter(
			enduser=self.request.GET.get("enduser"),
			enduser__active_status=True,
			topic__active_status=True,
		)
		topic_data = []
		enduser=self.request.GET.get("enduser")
		top_viewer = TopTopicViewer(queryset)
		if queryset.count() > 0:
			for index in queryset:
				orderbyList = ['-is_pinned_by_user','-id']
				topicdata = Topic.objects.filter(id=index.topic_id).order_by(*orderbyList)
				for topic in topicdata:
					topic_dict = {}
					topic_dict['id'] = topic.id
					topic_dict['title'] = topic.title
					topic_count = TopicViews.objects.filter(topic_id=topic.id)
					if topic_count.count() > 0:
						topic_dict["topic_view_count"] = topic_count.count()
					else:
						topic_dict["topic_view_count"] = 0
					topic_dict["genre_id"] = topic.genre.id
					topic_dict["genre"] = topic.genre.name
					topic_dict["area_id"] = topic.area.id
					topic_dict["area"] = topic.area.name
					topic_dict["title"] = topic.title
					topic_dict["content"] = topic.content
					topic_dict["shop"] = None
					if topic.shop:
						topic_dict["shop"] = topic.shop.id
						topic_dict["shop_name"] = topic.shop.name
					topic_dict["enduser"] = {}
					topic_dict["enduser"]["id"] = topic.enduser.id

					if topic.enduser.id == enduser:
						fcount = Follow.objects.filter(followee=enduser)
						topic_dict["enduser"]["follower_count"] = fcount.count()
					else:
						fcount = Follow.objects.filter(followee=enduser)
						topic_dict["enduser"]["follower_count"] = fcount.count()

						followExist = Follow.objects.filter(followee=topic.enduser.id, follower=enduser)
						topic_dict["enduser"]["is_followed"] = False
						if followExist.count():
							topic_dict["enduser"]["is_followed"] = True
							topic_dict["enduser"]["follow_id"] = followExist[0].id
					topic_dict["enduser"]["name"] = topic.enduser.name
					topic_dict["enduser"]["username"] = topic.enduser.auth_user.username
					topic_dict["enduser"]["avatar"] = topic.enduser.avatar
					topic_dict["is_pinned_by_user"] = topic.is_pinned_by_user
					topic_dict["is_pinned_by_shop"] = topic.is_pinned_by_shop
					topic_dict["is_report"]=topic.is_report
					topic_dict["active_status"]=topic.active_status
					topic_dict["is_hidden"]=topic.is_hidden
					topic_dict["active_status"] = topic.active_status
					topic_dict["like_count"] = TopicLike.objects.filter(topic=topic).count()
					if topic_dict['like_count'] in top_viewer:
						topic_dict['top_viewer'] = True
					else:
						topic_dict['top_viewer'] = False
					topic_dict["is_liked"] = False
					likeExist = TopicLike.objects.filter(
						topic=topic, enduser__id=enduser
					)
					if likeExist.count():
						topic_dict["is_liked"] = True
						topic_dict["like_id"] = likeExist[0].id
					topic_dict["comment_count"] = TopicComment.objects.filter(topic=topic).count()
					topic_dict["is_favorite"] = False
					favoriteExist = FavoriteTopic.objects.filter(
						topic=topic, enduser__id=enduser
					)
					if favoriteExist.count():
						topic_dict["is_favorite"] = True
						topic_dict["favorite_id"] = favoriteExist[0].id
						fav_count = FavoriteTopic.objects.filter(
						topic=topic)
						topic_dict["favorite_count"] = fav_count.count()
					else:
						 topic_dict["favorite_count"] = 0
					topic_dict["created_at"] = topic.created_at.strftime("%Y/%m/%d %I:%M %p")
					topic_dict["updated_at"] = topic.updated_at.strftime("%Y/%m/%d %I:%M %p")
					topic_data.append(topic_dict)
		
		from socialfeatures.models import FavoriteShop

		query = FavoriteShop.objects.filter(
			enduser=self.request.GET.get("enduser"),
			enduser__active_status=True,
			shop__active_status=True,
			shop__is_banned=False,
		)
		shop_data = []
		if query.count() > 0:
			for s in query:
				shopdata = Shop.objects.filter(id=s.shop_id)
				for shop in shopdata:
					temp = {}
					temp["id"] = shop.id
					temp["genre"] = shop.genre.name
					temp["city"] = shop.city.name
					temp["address"] = shop.address
					temp["name"] = shop.name
					temp["profile_photo"] = None
					try:
						temp["profile_photo"] = (request.build_absolute_uri()).replace(
							request.get_full_path(), ""
						) + shop.profile_photo.url
					except Exception as e:
						print(str(e))
					try:
						temp["banner"] = (request.build_absolute_uri()).replace(
							request.get_full_path(), ""
						) + shop.banner.url
					except Exception as e:
						print(str(e))

					temp["opening_time"] = shop.opening_time
					temp["closing_time"] = shop.closing_time
					temp["is_24hr_open"] = shop.is_24hr_open
					temp["phone_number"] = str(shop.phone_number)
					temp["staff_attitude_rating"] = shop.staff_attitude_rating
					temp["pay_rating"] = shop.pay_rating
					temp["user_rating"] = shop.user_rating
					temp["views_count"] = shop.views_count
					temp["is_premium"] = shop.is_premium
					temp["is_banned"] = shop.is_banned
					temp["is_favorite"] = False
					from socialfeatures.models import FavoriteShop
					favoriteExist = FavoriteShop.objects.filter(
						shop=shop, enduser__id=enduser
					)
					if favoriteExist.count():
						temp["is_favorite"] = True
						temp["favorite_id"] = favoriteExist[0].id
					temp["active_status"] = shop.active_status
					shop_data.append(temp)

		
		queryset = FavoriteReview.objects.filter(
			enduser=self.request.GET.get("enduser"),

		)
		review_data = []
		enduser=self.request.GET.get("enduser")
		top_viewer = TopReviewViewer(queryset)
		if queryset.count() > 0:
			for index in queryset:
				orderbyList = ['-is_pinned_by_user','-id']
				reviewdata = Review.objects.filter(id=index.review_id).order_by(*orderbyList)
				for review in reviewdata:
					temp = {}
					temp["id"] 				= review.id
					temp["review"]		    = review.content
					temp["rating"]          = review.rating
					temp["is_pinned_by_user"] = review.is_pinned_by_user
					temp["is_pinned_by_shop"] = review.is_pinned_by_shop
					review_count = FavoriteReview.objects.filter(review_id=review.id)
					if review_count.count() > 0:
						temp["review_view_count"] = review_count.count()
					else:
						temp["review_view_count"] = 0

					temp["enduser"] = {}
					temp["enduser"]["id"] = review.enduser.id

					if review.enduser.id == enduser:
						fcount = Follow.objects.filter(followee=enduser)
						temp["enduser"]["follower_count"] = fcount.count()
					else:
						fcount = Follow.objects.filter(followee=enduser)
						temp["enduser"]["follower_count"] = fcount.count()

						followExist = Follow.objects.filter(followee=review.enduser.id, follower=enduser)
						temp["enduser"]["is_followed"] = False
						if followExist.count():
							temp["enduser"]["is_followed"] = True
							temp["enduser"]["follow_id"] = followExist[0].id

					temp["enduser"]["name"] = review.enduser.name
					temp["enduser"]["username"] = review.enduser.auth_user.username
					temp["enduser"]["avatar"] = review.enduser.avatar
					temp["is_report"]=review.is_report
					temp["active_status"]=review.is_active
					temp["is_hidden"]=review.is_hidden

					temp["like_count"] = ReviewLike.objects.filter(review_id=review.id).count()
					
					if temp['like_count'] in top_viewer:
						temp['top_viewer'] = True
					else:
						temp['top_viewer'] = False

					temp["is_liked"] = False
					likeExist = ReviewLike.objects.filter(
						review_id=review.id, enduser__id=enduser
					)
					if likeExist.count():
						temp["is_liked"] = True
						temp["like_id"] = likeExist[0].id
					temp["is_favorite"] = False
					favoriteExist = FavoriteReview.objects.filter(
						review_id=review.id, enduser__id=enduser
					)
					if favoriteExist.count():
						temp["is_favorite"] = True
						temp["favorite_id"] = favoriteExist[0].id
						fav_count = FavoriteReview.objects.filter(
						review_id=review.id)
						temp["favorite_count"] = fav_count.count()
					else:
						 temp["favorite_count"] = 0
					temp["created_at"] = review.created_at.strftime("%Y/%m/%d %I:%M %p")
					temp["updated_at"] = review.updated_at.strftime("%Y/%m/%d %I:%M %p")
					review_data.append(temp)
		return Response(
				{
				"success":True,
				"topic": topic_data,
				"shop" : shop_data,
				"review" : review_data
				},
				status=HTTP_200_OK
			)
class EnduserListData(ListAPIView):
	"""
	EndUser List GET API
	  Params:  {
			"page_no": 1,
			"page_size": 10,
			"search"  : "" (optional)
		}
		Service usage and description : This API is used to list enduser.
		Authentication Required : YES

	"""

	permission_classes = (
		IsAuthenticated,
	)
	serializer_class = EndUserSerializer
	queryset = EndUser.objects.all()

	def get(self, request):
		try:
			p_no= self.request.GET.get("page_no")
			p_size = self.request.GET.get("page_size")
			search = self.request.GET.get("search")
			page_no = 1
			page_size = 10
			if search != None:
				enduser_data = EndUser.objects.filter(name__icontains=search)
			else:
				enduser_data = EndUser.objects.filter()
			if p_no != None:
				page_no = int(self.request.GET.get("page_no"))
			if p_size != None:
				page_size = int(self.request.GET.get("page_size"))
			try:
				if page_size > 200:
					page_size = 200
				pages = Paginator(enduser_data, page_size)
				end_user_data = pages.page(page_no)
			except PageNotAnInteger:
				page_no = 1
				end_user_data = pages.page(page_no)
			except EmptyPage:
				page_no = pages.num_pages
				end_user_data = pages.page(page_no)
			page_count = pages.count
			page_info = {
				"page_no": page_no,
				"page_size": page_size,
				"total_users": page_count,
				"total_pages" : pages.num_pages
			}
			final_data = []
			for index in range(len(end_user_data.object_list)):
				p_list ={}
				p_list['id'] = end_user_data[index].id
				p_list['name'] = end_user_data[index].name
				p_list['description'] = end_user_data[index].description
				p_list['area'] =  end_user_data[index].area.name if end_user_data[index].area else ''
				p_list['active_status'] = end_user_data[index].active_status
				final_data.append(p_list)
			return Response(
				{"success": True, 
				"data": final_data,
				"page": page_info}, status=HTTP_200_OK
			)
		except Exception as e:
			return Response(
				{"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
			)


class SearchData(ListAPIView):
	"""
	Search GET API

		Service Usage and Description : This API is used to Search.
		Authentication Required : YES

		Params : {

			"type"  :   "all / topic/ review" (optional)
			"area"  :   "1",  (optional)
			"state" :   "1"  (optional)
			"city"  :   "1" (optional)
			"genre" :   "1"
			"enduser" : "1"
		}

		Response : {
			"data" : final_data
		}
	"""

	permission_classes = (IsAuthenticated,)
	def get(self, request):
		try:
			types = self.request.GET.get("types")
			area = self.request.GET.get("area")
			state = self.request.GET.get("state")
			city = self.request.GET.get("city")
			genre = self.request.GET.get("genre")
			user = request.user
			enduser = EndUser.objects.filter(auth_user=user)
			enduser_id = None
			if enduser.count():
				enduser_id = enduser[0].id
			final_data = []
			temp = {}
			if types == 'all':
				topic_data = Topic.objects.filter(active_status=True)
				top_viewer = TopViewer(topic_data)
				if city != None and area != None:
					topic_data = topic_data.filter(city=city,area=area).order_by('-id')
				if genre != None:
					topic_data = topic_data.filter(genre=genre)
				if topic_data.count() > 0:
					temp['topic_data'] = []
					for topic in topic_data:
						t = {}
						t['id'] = topic.id
						t['title'] = topic.title
						topic_count = TopicViews.objects.filter(
							topic_id=topic.id)
						if topic_count.count() > 0:
							t["topic_view_count"] = topic_count.count()
						else:
							t["topic_view_count"] = 0
						t["genre_id"] = topic.genre.id if topic.genre else ''
						t["genre"] = topic.genre.name if topic.genre else ''
						t["area_id"] = topic.area.id if  topic.area else ''
						t["area"] = topic.area.name if topic.area else ''
						t["title"] = topic.title
						t["content"] = topic.content
						t["shop"] = None
						if topic.shop != None:
							t["shop"] = topic.shop.id
							t["shop_name"] = topic.shop.name
						t["enduser"] = {}
						t["enduser"]["id"] = topic.enduser.id
						if topic.enduser.id == enduser_id:
							fcount = Follow.objects.filter(followee=topic.enduser.id)
							t["enduser"]["follower_count"] = fcount.count()
						else:
							fcount = Follow.objects.filter(followee=topic.enduser.id)
							t["enduser"]["follower_count"] = fcount.count()

							followExist = Follow.objects.filter(followee=topic.enduser.id, follower=enduser_id)
							t["enduser"]["is_followed"] = False
							if followExist.count():
								t["enduser"]["is_followed"] = True
								t["enduser"]["follow_id"] = followExist[0].id
						t["enduser"]["name"] = topic.enduser.name
						t["enduser"]["username"] = topic.enduser.auth_user.username
						t["enduser"]["avatar"] = topic.enduser.avatar
						t["is_pinned_by_user"] = topic.is_pinned_by_user
						t["is_pinned_by_shop"] = topic.is_pinned_by_shop
						t["is_report"]=topic.is_report
						t["active_status"]=topic.active_status
						t["is_hidden"]=topic.is_hidden
						t["active_status"] = topic.active_status
						t["like_count"] = TopicLike.objects.filter(topic=topic).count()
						t["is_liked"] = False
						if t['like_count'] in top_viewer:
							t['top_viewer'] = True
						else:
							t['top_viewer'] = False
						likeExist = TopicLike.objects.filter(
							topic=topic, enduser__id=enduser_id
						)
						if likeExist.count():
							t["is_liked"] = True
							t["like_id"] = likeExist[0].id
						t["comment_count"] = TopicComment.objects.filter(topic=topic).count()
						t["is_favorite"] = False
						from socialfeatures.models import FavoriteTopic
						favoriteExist = FavoriteTopic.objects.filter(
							topic=topic, enduser__id=enduser_id
						)
						if favoriteExist.count():
							t["is_favorite"] = True
							t["favorite_id"] = favoriteExist[0].id
							fav_count = FavoriteTopic.objects.filter(
							topic=topic)
							t["favorite_count"] = fav_count.count()
						else:
							 t["favorite_count"] = 0
						t["created_at"] = topic.created_at.strftime("%Y/%m/%d %I:%M %p")
						t["updated_at"] = topic.updated_at.strftime("%Y/%m/%d %I:%M %p")
						temp['topic_data'].append(t)
				
				if city != None and area != None:
					shop_id = Shop.objects.filter(city=city)
					temp['review_data'] = []
					if shop_id.count() > 0:
						shop_id = shop_id[0].id
						review_data = Review.objects.filter(shop=shop_id)
						top_viewer = ReviewViewer(review_data)
						if review_data.count() > 0:
							serializer = ReviewDataSerializer(review_data, many=True)
							data = serializer.data
							k = 0
							for review in data:
								t = review
								if review_data[k].shop.profile_photo:
									t["shop"]["profile_photo"] = request.build_absolute_uri(
										review_data[k].shop.profile_photo.url
									)
								if review_data[k].enduser.avatar:
									t["enduser"]["avatar"] = request.build_absolute_uri(
										review_data[k].enduser.avatar
									)
								likeExist = ReviewLike.objects.filter(
									review__id=t["id"], enduser__id=enduser_id
								)
								fcount = Follow.objects.filter(followee=t["enduser"]['id'])
								if fcount.count() > 0:
									t["enduser"]["follower_count"] = fcount.count()
								else:
									t["enduser"]["follower_count"] = 0
								followExist = Follow.objects.filter(followee=t["enduser"]['id'], follower=enduser_id)
								t["enduser"]["is_followed"] = False
								if followExist.count():
									t["enduser"]["is_followed"] = True
									t["enduser"]["follow_id"] = followExist[0].id

								like_count = ReviewLike.objects.filter(
									review__id=t["id"])
								t['like_count'] = like_count.count()
								
								if t['like_count'] in top_viewer:
									t['top_viewer'] = True
								else:
									t['top_viewer'] = False

								t["is_liked"] = False
								if likeExist.count():
									t["is_liked"] = True
									t["like_id"] = likeExist[0].id
								
								t["is_favorite"] = False
								favoriteExist = FavoriteReview.objects.filter(
									review_id=t['id'], enduser__id=enduser_id
								)
								if favoriteExist.count():
									t["is_favorite"] = True
									t["favorite_id"] = favoriteExist[0].id
									fav_count = FavoriteReview.objects.filter(review_id=t['id'])
									t["favorite_count"] = fav_count.count()
								else:
									 t["favorite_count"] = 0
								t['comment_count'] = ReviewComment.objects.filter(review=t['id']).count()

								k = k + 1
								temp['review_data'].append(review)
			
		
			if types == 'topic':
				topic_data = Topic.objects.filter(active_status=True)
				top_viewer = TopViewer(topic_data)
				if city != None and area != None:
					topic_data = topic_data.filter(city=city,area=area).order_by('-id')
				if genre != None:
					topic_data = topic_data.filter(genre=genre)
				if topic_data.count() > 0:
					temp['topic_data'] = []
					for topic in topic_data:
						t = {}
						t['id'] = topic.id
						t['title'] = topic.title
						topic_count = TopicViews.objects.filter(
							topic_id=topic.id)
						if topic_count.count() > 0:
							t["topic_view_count"] = topic_count.count()
						else:
							t["topic_view_count"] = 0
						t["genre_id"] = topic.genre.id if topic.genre else ''
						t["genre"] = topic.genre.name if topic.genre else ''
						t["area_id"] = topic.area.id if  topic.area else ''
						t["area"] = topic.area.name if topic.area else ''
						t["title"] = topic.title
						t["content"] = topic.content
						t["shop"] = None
						if topic.shop != None:
							t["shop"] = topic.shop.id
							t["shop_name"] = topic.shop.name
						t["enduser"] = {}
						t["enduser"]["id"] = topic.enduser.id
						if topic.enduser.id == enduser_id:
							fcount = Follow.objects.filter(followee=topic.enduser.id)
							t["enduser"]["follower_count"] = fcount.count()
						else:
							fcount = Follow.objects.filter(followee=topic.enduser.id)
							t["enduser"]["follower_count"] = fcount.count()

							followExist = Follow.objects.filter(followee=topic.enduser.id, follower=enduser_id)
							t["enduser"]["is_followed"] = False
							if followExist.count():
								t["enduser"]["is_followed"] = True
								t["enduser"]["follow_id"] = followExist[0].id
						t["enduser"]["name"] = topic.enduser.name
						t["enduser"]["username"] = topic.enduser.auth_user.username
						t["enduser"]["avatar"] = topic.enduser.avatar
						t["is_pinned_by_user"] = topic.is_pinned_by_user
						t["is_pinned_by_shop"] = topic.is_pinned_by_shop
						t["is_report"]=topic.is_report
						t["active_status"]=topic.active_status
						t["is_hidden"]=topic.is_hidden
						t["active_status"] = topic.active_status
						t["like_count"] = TopicLike.objects.filter(topic=topic).count()
						if t['like_count'] in top_viewer:
							t['top_viewer'] = True
						else:
							t['top_viewer'] = False
						t["is_liked"] = False
						likeExist = TopicLike.objects.filter(
							topic=topic, enduser__id=enduser_id
						)
						if likeExist.count():
							t["is_liked"] = True
							t["like_id"] = likeExist[0].id
						t["comment_count"] = TopicComment.objects.filter(topic=topic).count()
						t["is_favorite"] = False
						from socialfeatures.models import FavoriteTopic
						favoriteExist = FavoriteTopic.objects.filter(
							topic=topic, enduser__id=enduser_id
						)
						if favoriteExist.count():
							t["is_favorite"] = True
							t["favorite_id"] = favoriteExist[0].id
							fav_count = FavoriteTopic.objects.filter(
							topic=topic)
							t["favorite_count"] = fav_count.count()
						else:
							 t["favorite_count"] = 0
						t["created_at"] = topic.created_at.strftime("%Y/%m/%d %I:%M %p")
						t["updated_at"] = topic.updated_at.strftime("%Y/%m/%d %I:%M %p")
						temp['topic_data'].append(t)
			if types == 'review':
				if city != None and area != None:
					shop_id = Shop.objects.filter(city=city)
					temp['review_data'] = []
					if shop_id.count() > 0:
						shop_id = shop_id[0].id
						review_data = Review.objects.filter(shop=shop_id)
						top_viewer = ReviewViewer(queryset)

						if review_data.count() > 0:
							serializer = ReviewDataSerializer(review_data, many=True)
							data = serializer.data
							temp['review_data'] = []
							k = 0
							for review in data:
								t = review
								if review_data[k].shop.profile_photo:
									t["shop"]["profile_photo"] = request.build_absolute_uri(
										review_data[k].shop.profile_photo.url
									)
								if review_data[k].enduser.avatar:
									t["enduser"]["avatar"] = request.build_absolute_uri(
										review_data[k].enduser.avatar
									)
								likeExist = ReviewLike.objects.filter(
									review__id=t["id"], enduser__id=enduser_id
								)
								fcount = Follow.objects.filter(followee=t["enduser"]['id'])
								if fcount.count() > 0:
									t["enduser"]["follower_count"] = fcount.count()
								else:
									t["enduser"]["follower_count"] = 0
								followExist = Follow.objects.filter(followee=t["enduser"]['id'], follower=enduser_id)
								t["enduser"]["is_followed"] = False
								if followExist.count():
									t["enduser"]["is_followed"] = True
									t["enduser"]["follow_id"] = followExist[0].id
								like_count = ReviewLike.objects.filter(
									review__id=t["id"])
								t['like_count'] = like_count.count()
								if t['like_count'] in top_viewer:
									t['top_viewer'] = True
								else:
									t['top_viewer'] = False
								t["is_liked"] = False
								if likeExist.count():
									t["is_liked"] = True
									t["like_id"] = likeExist[0].id
								t["is_favorite"] = False
								favoriteExist = FavoriteReview.objects.filter(
									review_id=t['id'], enduser__id=enduser_id
								)
								if favoriteExist.count():
									t["is_favorite"] = True
									t["favorite_id"] = favoriteExist[0].id
									fav_count = FavoriteReview.objects.filter(review_id=t['id'])
									t["favorite_count"] = fav_count.count()
								else:
									 t["favorite_count"] = 0
								t['comment_count'] = ReviewComment.objects.filter(review=t['id']).count()
								k = k + 1
			final_data.append(temp)
			return Response(final_data, status=HTTP_200_OK)
		

		except Exception as e:
			return Response(
				{"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
			)



class SuperUserReport(ListAPIView):
	"""
	Monthly Report For shop/topic/review GET API

		Service Usage and Description : This API is used to Monthly Report For shop/topic/review.
		Authentication Required : YES

		Params : {

		}

		Response : {
			"data" : final_data
		}
	"""

	permission_classes = (IsAuthenticated,IsSuperAdmin)
	def get(self, request):
		try:
			from datetime import datetime
			from django.db.models import Max,Min
			now = datetime.now()
			month = now.month
			year = now.year

			
			shop = Shop.objects.all()
			min_id = shop.aggregate(Min('id'))

			min_data = Shop.objects.filter(id=min_id['id__min'])
			min_year = min_data[0].created_at.year
			min_month = min_data[0].created_at.month

			max_id = shop.aggregate(Max('id'))
			max_data = Shop.objects.filter(id=max_id['id__max'])
			max_year = max_data[0].created_at.year
			max_month = max_data[0].created_at.month
		
			final_list = []
			for y in range(min_year,max_year+1):
				for m in range(min_month,max_month+1):
					temp = {}
					alshop   = Shop.objects.filter(created_at__month=month,created_at__year=year)
					if alshop.count() > 0:
						allreview = Review.objects.filter(created_at__month=month,created_at__year=year)
						alltopic  = Topic.objects.filter(created_at__month=month,created_at__year=year)
						allenduser = EndUser.objects.filter(created_at__month=month,created_at__year=year)
						allprimiumshop = Shop.objects.filter(created_at__month=month,\
							created_at__year=year,is_premium=1)
						temp['year'] = y
						temp['month'] = alshop[0].created_at.strftime("%m")
						temp['shop_count'] = alshop.count()
						temp['review_count'] = allreview.count()
						temp['topic_count'] = alltopic.count()
						temp['user_count'] = allenduser.count()
						temp['premium_shop_count'] = allprimiumshop.count()

						final_list.append(temp)
			page_info = {
				"start_year" : min_year,
				"end_year" : max_year
			}
			return Response({"success": True, 
				"data": final_list,
				"year": page_info
				}, status=HTTP_200_OK)
		except Exception as e:
			return Response(
				{"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
			)



class ShopReport(ListAPIView):
	"""
	Monthly Report For shopview/topic/review GET API

		Service Usage and Description : This API is used to Monthly Report For shopview/topic/review.
		Authentication Required : YES

		Params : {
			"year" : 2020
		}

		Response : {
			"data" : final_data
		}
	"""

	permission_classes = (IsAuthenticated,IsShopOwner)
	def get(self, request):
		try:
			from datetime import datetime
			from django.db.models import Max,Min
			shop_id = ShopOwner.objects.filter(auth_user_id=request.user.id)
			if shop_id.count() > 0:
				shop_id = shop_id[0].shop_id

			now = datetime.now()
			month = now.month
			year = now.year
			min_year = []
			max_year = []

			min_month = []
			max_month = []
			
			shop = ShopViews.objects.filter(shop_id= shop_id)
			if shop.count() > 0:
				min_id = shop.aggregate(Min('id'))


				min_data = ShopViews.objects.filter(id=min_id['id__min'])
				minyear = min_data[0].created_at.year
				minmonth = min_data[0].created_at.month

				max_id = shop.aggregate(Max('id'))
				max_data = ShopViews.objects.filter(id=max_id['id__max'])
				maxyear = max_data[0].created_at.year
				maxmonth = max_data[0].created_at.month
				
				min_year.append(minyear)
				max_year.append(maxyear)

				min_month.append(minmonth)
				max_month.append(maxmonth)
			
			review = Review.objects.filter(shop_id= shop_id)
			if review.count() > 0:
				min_id = review.aggregate(Min('id'))

				min_data = Review.objects.filter(id=min_id['id__min'])
				minyear = min_data[0].created_at.year
				minmonth = min_data[0].created_at.month

				max_id = review.aggregate(Max('id'))
				max_data = Review.objects.filter(id=max_id['id__max'])
				maxyear = max_data[0].created_at.year
				maxmonth = max_data[0].created_at.month


				min_year.append(minyear)
				max_year.append(maxyear)

				min_month.append(minmonth)
				max_month.append(maxmonth)

			topic = Topic.objects.filter(shop_id= shop_id)
			if topic.count() > 0:
				min_id = topic.aggregate(Min('id'))

				min_data = Topic.objects.filter(id=min_id['id__min'])
				minyear = min_data[0].created_at.year
				minmonth = min_data[0].created_at.month

				max_id = topic.aggregate(Max('id'))
				max_data = Topic.objects.filter(id=max_id['id__max'])
				maxyear = max_data[0].created_at.year
				maxmonth = max_data[0].created_at.month

				min_year.append(minyear)
				max_year.append(maxyear)

				min_month.append(minmonth)
				max_month.append(maxmonth)

			jobapplication = JobApplication.objects.filter(shop_id = shop_id)
			if jobapplication.count() > 0:
				min_id = jobapplication.aggregate(Min('id'))

				min_data = JobApplication.objects.filter(id=min_id['id__min'])
				minyear = min_data[0].created_at.year
				minmonth = min_data[0].created_at.month

				max_id = jobapplication.aggregate(Max('id'))
				max_data = JobApplication.objects.filter(id=max_id['id__max'])
				maxyear = max_data[0].created_at.year
				maxmonth = max_data[0].created_at.month

				min_year.append(minyear)
				max_year.append(maxyear)

				min_month.append(minmonth)
				max_month.append(maxmonth)

			year = None
			year = self.request.GET.get("year")
			if len(min_year) > 0:
				myear = max(min_year)
				maxyear = max(max_year)
				
				mmonth = max(min_month)
				maxmonth = max(max_month)

			if year == None:
				final_list = []
				for y in range(myear,maxyear+1):
					for m in range(mmonth,maxmonth+1):
						temp = {}
						alshop   = ShopViews.objects.filter(created_at__month=m,created_at__year=y,shop_id= shop_id)

						if alshop.count() > 0:
							temp['shopview_count'] = alshop.count()
						else:
							temp['shopview_count'] = 0

						allreview = Review.objects.filter(created_at__month=m,created_at__year=y,shop_id= shop_id)
						if allreview.count() > 0:
							temp['review_count'] = allreview.count()
						else:
							temp['review_count'] = 0
						alltopic  = Topic.objects.filter(created_at__month=m,created_at__year=y,shop_id= shop_id)
						if alltopic.count() > 0:
							temp['topic_count'] = alltopic.count()
						else:
							temp['topic_count'] = 0
						alljob = JobApplication.objects.filter(created_at__month=m,created_at__year=y,shop_id= shop_id)
						if alljob.count() > 0:
							temp["jobapplication_count"] = alljob.count()
						else:
							temp["jobapplication_count"] = 0
						temp['year'] = y
						temp['month'] = m
						final_list.append(temp)
			else:
				final_list = []
				if int(year) < maxyear:
					pass
				else:
					for m in range(mmonth,maxmonth+1):
						temp = {}
						alshop   = ShopViews.objects.filter(created_at__month=month,created_at__year=year,shop_id= shop_id)
						if alshop.count() > 0:
							temp['shopview_count'] = alshop.count()
						else:
							temp['shopview_count'] = 0
						allreview = Review.objects.filter(created_at__month=month,created_at__year=year,shop_id= shop_id)
						if allreview.count() > 0:
							temp['review_count'] = allreview.count()
						else:
							temp['review_count'] = 0
						alltopic  = Topic.objects.filter(created_at__month=m,created_at__year=year,shop_id= shop_id)
						if alltopic.count() > 0:
							temp['topic_count'] = alltopic.count()
						else:
							temp['topic_count'] = 0
						alljob = JobApplication.objects.filter(created_at__month=m,created_at__year=year,shop_id= shop_id)
						if alljob.count() > 0:
							temp["jobapplication_count"] = alljob.count()
						else:
							temp["jobapplication_count"] = 0
						temp['year'] = int(year)
						temp['month'] = m
						final_list.append(temp)
				
			page_info = {
				"start_year" : myear,
				"end_year" : maxyear
			}
			return Response({"success": True, 
				"data": final_list,
				"page": page_info}, status=HTTP_200_OK)
		except Exception as e:
			return Response(
				{"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
			)

class ShopOwnerListData(ListAPIView):
	"""
	ShopOwner List GET API
	  Params:  {
			"page_no": 1,
			"page_size": 10,
		}
		Service usage and description : This API is used to shop
		Authentication Required : YES

	"""

	permission_classes = (
		IsAuthenticated,
	)
	serializer_class = ShopOwnerSerializer
	queryset = ShopOwner.objects.all()

	def get(self, request):
		try:
			p_no= self.request.GET.get("page_no")
			p_size = self.request.GET.get("page_size")
			search = self.request.GET.get("search")
			page_no = 1
			page_size = 10
			shopowner_data = ShopOwner.objects.filter()
			if p_no != None:
				page_no = int(self.request.GET.get("page_no"))
			if p_size != None:
				page_size = int(self.request.GET.get("page_size"))
			try:
				if page_size > 200:
					page_size = 200
				pages = Paginator(shopowner_data, page_size)
				shop_owner_data = pages.page(page_no)
			except PageNotAnInteger:
				page_no = 1
				shop_owner_data = pages.page(page_no)
			except EmptyPage:
				page_no = pages.num_pages
				shop_owner_data = pages.page(page_no)
			page_count = pages.count
			page_info = {
				"page_no": page_no,
				"page_size": page_size,
				"total_users": page_count,
				"total_pages" : pages.num_pages
			}
			final_data = []
			for index in range(len(shop_owner_data.object_list)):
				p_list ={}
				p_list['id'] = shop_owner_data[index].id
				p_list['name'] = shop_owner_data[index].name
				p_list["email"] = shop_owner_data[index].email
				p_list["shop_name"] = shop_owner_data[index].shop.name
				p_list["genre"] = shop_owner_data[index].shop.genre.id
				p_list["city"] = shop_owner_data[index].shop.city.id
				p_list["shop_url"] = shop_owner_data[index].shop.url
				p_list["shop_address"] = shop_owner_data[index].shop.address
				p_list["opening_time"] = shop_owner_data[index].shop.opening_time
				p_list["closing_time"] = shop_owner_data[index].shop.closing_time
				p_list["shop_phone_number"] = shop_owner_data[index].shop.phone_number
				p_list["plan"] = shop_owner_data[index].shop.is_premium
				p_list["comment"] = shop_owner_data[index].shop.comment
				p_list['active_status'] = shop_owner_data[index].active_status
				final_data.append(p_list)
			return Response(
				{"success": True, 
				"data": final_data,
				"page": page_info}, status=HTTP_200_OK
			)
		except Exception as e:
			return Response(
				{"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
			)