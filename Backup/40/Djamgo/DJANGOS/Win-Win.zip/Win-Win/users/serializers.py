from rest_framework import serializers
from .models import *
from django.contrib.auth.models import User
from shops.serializers import ShopSerializer
from topic.models import *
from review.models import *


class EndUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = EndUser
        fields = "__all__"

class EndUserNameSerializer(serializers.ModelSerializer):
    class Meta:
        model = EndUser
        fields = ("id", "name", "avatar")

class UserLoginSerializer(serializers.Serializer):
    username = serializers.CharField(max_length=250, required=True)
    password = serializers.CharField(required=True)

    class Meta:
        model = User
        fields = ["username", "password"]


class ShopOwnerSerializer(serializers.ModelSerializer):
    class Meta:
        model = ShopOwner
        fields = "__all__"

class ShopOwnerDataSerializer(serializers.ModelSerializer):
    shop = ShopSerializer()
    class Meta:
        model = ShopOwner
        fields = "__all__"


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = "__all__"


def TopTopicViewer(queryset):
    top_viewer = []
    for index in queryset:
        topicdata = Topic.objects.filter(id=index.topic_id)
        for topic in topicdata:
            likecount = TopicLike.objects.filter(topic=topic.id).count()
            top_viewer.append(likecount)
    top_viewer.sort(reverse = True)
    return top_viewer[0:1]


def TopReviewViewer(queryset):
    top_viewer = []
    for index in queryset:
        reviewdata = Review.objects.filter(id=index.review_id)
        for review in reviewdata:
            likecount = ReviewLike.objects.filter(review=review.id).count()
            top_viewer.append(likecount)
    top_viewer.sort(reverse = True)
    return top_viewer[0:1]



def TopViewer(queryset):
    top_viewer = []
    for index in queryset:
        likecount = TopicLike.objects.filter(topic=index.id).count()
        top_viewer.append(likecount)
    top_viewer.sort(reverse = True)
    return top_viewer[0:1]


def ReviewViewer(queryset):
    top_viewer = []
    for index in queryset:
        likecount = ReviewLike.objects.filter(review=index.id).count()
        top_viewer.append(likecount)
    top_viewer.sort(reverse = True)
    return top_viewer[0:1]
