from django.contrib import admin
from .models import ShopOwner, EndUser

admin.site.register(ShopOwner)
admin.site.register(EndUser)
