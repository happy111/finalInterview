from socialfeatures.models import ShopViews, TopicViews


def DeleteViews():
    try:
        ShopViews.objects.all().delete()
        TopicViews.objects.all().delete()
        print("Success : Views Cycle Reset")
    except Exception as e:
        print("Failure : " + str(e))
