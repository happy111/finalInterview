from .models import *
from .serializers import (
    ReviewSerializer,
    ReviewCommentSerializer,
    ReviewLikeSerializer,
    ReviewDeletionRequestSerializer,
    shopUpdate,
    ReviewDataSerializer,
)
from rest_framework.views import APIView
from rest_framework.generics import (
    CreateAPIView,
    ListAPIView,
    DestroyAPIView,
    UpdateAPIView,
)
from rest_framework.permissions import IsAuthenticated
from winwin.permissions import IsShopOwner, IsNotBanned , IsSuperAdmin
from rest_framework.response import Response
from rest_framework.status import (
    HTTP_200_OK,
    HTTP_406_NOT_ACCEPTABLE,
    HTTP_401_UNAUTHORIZED,
)
import json
from socialfeatures.models import Follow,TopicViews,ReviewViews,FavoriteReview
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from users.models import *
from datetime import datetime, timedelta
from users.serializers import *

class ReviewCreation(CreateAPIView):
    """
    Review Creation POST API

        Service Usage and Description : This API is used to create Review.
        Authentication Required : YES

        Data : {
            "enduser" : "1",
            "shop"  :   "1",
            "rating"    :   "4",
            "content"   :   ""
        }

        Response : {
            "data" : final_data
        }
    """

    permission_classes = (IsAuthenticated, IsNotBanned)
    serializer_class = ReviewSerializer




class ActiveReviewListing(ListAPIView):
    """
    Active Review Listing GET API

        Service Usage and Description : This API is used to list active Reviews.
        Authentication Required : YES

        Params : {
            "shop"  :   "1"   (optional)
        }

        Response : {
            "data" : final_data
        }
    """

    permission_classes = (IsAuthenticated, IsNotBanned | IsShopOwner)
    serializer_class = ReviewDataSerializer

    def get_queryset(self):
        shop = self.request.GET.get("shop")
       # orderbyList = ['-is_pinned_by_user','-id']
        orderbyList = ['-id']
        if shop != None and shop != 'false':
            queryset = Review.objects.filter(shop=shop, is_hidden=False).order_by(*orderbyList)
        elif shop == 'false':
            queryset = Review.objects.filter(is_active=True).order_by(*orderbyList)
        else:
            queryset = Review.objects.filter(is_hidden=False).order_by(*orderbyList)
        return queryset

    def get(self, request):
        try:
            queryset = self.get_queryset()
            final_data = []
            serializer = ReviewDataSerializer(queryset, many=True)
            data = serializer.data
            enduser = EndUser.objects.filter(auth_user=request.user)
            enduser_id = None
            k = 0
            if enduser.count():
                enduser_id = enduser[0].id
            top_viewer = ReviewViewer(queryset)
            for review in data:
                temp = review
                if queryset[k].shop.profile_photo:
                    temp["shop"]["profile_photo"] = request.build_absolute_uri(
                        queryset[k].shop.profile_photo.url
                    )
                if queryset[k].enduser.avatar:
                    temp["enduser"]["avatar"] = request.build_absolute_uri(
                        queryset[k].enduser.avatar
                    )
                likeExist = ReviewLike.objects.filter(
                    review__id=temp["id"], enduser__id=enduser_id
                )
                
                fcount = Follow.objects.filter(followee=temp["enduser"]['id'])
                if fcount.count() > 0:
                    temp["enduser"]["follower_count"] = fcount.count()
                else:
                    temp["enduser"]["follower_count"] = 0

                followExist = Follow.objects.filter(followee=temp["enduser"]['id'], follower=enduser_id)
                temp["enduser"]["is_followed"] = False
                if followExist.count():
                    temp["enduser"]["is_followed"] = True
                    temp["enduser"]["follow_id"] = followExist[0].id

                like_count = ReviewLike.objects.filter(
                    review__id=temp["id"])
                temp['like_count'] = like_count.count()
                
                if temp['like_count'] in top_viewer:
                    temp['top_viewer'] = True
                else:
                    temp['top_viewer'] = False

                temp["is_liked"] = False
                if likeExist.count():
                    temp["is_liked"] = True
                    temp["like_id"] = likeExist[0].id
                
                temp["is_favorite"] = False
                favoriteExist = FavoriteReview.objects.filter(
                    review_id=temp['id'], enduser__id=enduser_id
                )
                if favoriteExist.count():
                    temp["is_favorite"] = True
                    temp["favorite_id"] = favoriteExist[0].id
                    fav_count = FavoriteReview.objects.filter(review_id=temp['id'])
                    temp["favorite_count"] = fav_count.count()
                else:
                     temp["favorite_count"] = 0
                temp['comment_count'] = ReviewComment.objects.filter(review=temp['id']).count()
                final_data.append(temp)
                k = k + 1
            return Response(final_data, status=HTTP_200_OK)
        except Exception as e:
            return Response(
                {"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
            )


class AllReviewListing(ListAPIView):
    """
    All Review Listing GET API

        Service Usage and Description : This API is used to list all Reviews.
        Authentication Required : YES

        Params : {
            "shop"  :   "1"
        }

        Response : {
            "data" : final_data
        }
    """

    permission_classes = (IsAuthenticated, IsShopOwner)
    serializer_class = ReviewDataSerializer

    def get_queryset(self):
        queryset = Review.objects.filter(shop=self.request.GET.get("shop"))
        return queryset

    def get(self, request):
        try:
            print("vvvvvvvvvvvvvvvv",requests.get.user)
            queryset = self.get_queryset()
            final_data = []
            serializer = ReviewDataSerializer(queryset, many=True)
            data = serializer.data
            enduser = EndUser.objects.filter(auth_user=request.user)
            enduser_id = None
            k = 0
            if enduser.count():
                enduser_id = enduser[0].id
            for review in data:
                temp = review
                if queryset[k].shop.profile_photo:
                    temp["shop"]["profile_photo"] = request.build_absolute_uri(
                        queryset[k].shop.profile_photo.url
                    )
                if queryset[k].enduser.avatar:
                    temp["enduser"]["avatar"] = request.build_absolute_uri(
                        queryset[k].enduser.avatar
                    )
                likeExist = ReviewLike.objects.filter(
                    review__id=temp["id"], enduser__id=enduser_id
                )
                
                like_count = ReviewLike.objects.filter(
                    review__id=temp["id"])
                temp['like_count'] = like_count.count()
                temp["is_liked"] = False
                if likeExist.count():
                    temp["is_liked"] = True
                    temp["like_id"] = likeExist[0].id
                final_data.append(temp)
                k = k + 1
            return Response(final_data, status=HTTP_200_OK)
        except Exception as e:
            return Response(
                {"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
            )


class ReviewCountListing(ListAPIView):
    """
    Review Count Listing GET API

        Service Usage and Description : This API is used to count all Reviews for a Shop.
        Authentication Required : YES

        Params : {
            "shop"  :   "1"
        }

        Response : {
            "success" : true,
            "count" : 1
        }
    """

    permission_classes = (IsAuthenticated, IsNotBanned | IsShopOwner)
    serializer_class = ReviewSerializer

    def get(self, request):
        try:
            reviews = Review.objects.filter(shop=self.request.GET.get("shop"))
            return Response(
                {"success": True, "count": reviews.count()}, status=HTTP_200_OK
            )
        except Exception as e:
            return Response(
                {"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
            )

class ReviewDeleteHiddenCountList(ListAPIView):
    """
    Review Hidden Deleted Count Listing Get API
        Usage in Reviews Dashboard: This API is used to count all hidden Reviews and Deleted Reviews for a Shop
        Authentication Required: YES
        params : {
            "shop" : "1"
        }
        Response: {
            "sucess" : true,
            "hidden_count" : 1,
            "active_count" : 1
        }
    """

    permission_classes = (IsAuthenticated,IsNotBanned | IsShopOwner)
    serializer_class = ReviewSerializer

    def get(self,request):
        try:
            hiddenreviews = Review.objects.filter(shop=self.request.GET.get("shop"),is_hidden=True)
            activereviews = Review.objects.filter(shop=self.request.GET.get("shop"),is_active=False)
            return Response(
                {"success":True,"hidden_count": hiddenreviews.count(),"active_count":activereviews.count()},status=HTTP_200_OK
            )
        except Exception as e:
            return Response(
                {"success": False,"message" : str(e)},status=HTTP_406_NOT_ACCEPTABLE
            )
            
class ReviewUpdation(UpdateAPIView):
    """
    Review Updation PUT API

        Service Usage and Description : This API is used to update Review.
        Authentication Required : YES

        Data : {
            "id" : "1",
            "is_hidden": true
        }

        Response : {
            "success": True,
            "message": "Review Updated."
      
    """

    permission_classes = (IsAuthenticated, IsShopOwner | IsNotBanned)
    serializer_class = ReviewSerializer

    def put(self, request):
        try:
            data = request.data
            review = Review.objects.filter(id=data["id"])
            if review.count() == 0:
                raise Exception("No Review with given id.")
            serializer = ReviewSerializer(review[0], data=data, partial=True)
            if serializer.is_valid(raise_exception=True):
                if "rating" in data:
                    shopUpdate(
                        prev_rating=review[0].rating,
                        rating=data["rating"],
                        shopId=review[0].shop.id,
                        opType="Update",
                    )
                serializer.save()
                return Response(
                    {"success": True, "message": "Review Updated."},
                    status=HTTP_200_OK,
                )
        except Exception as e:
            return Response(
                {"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
            )

class ReveiwAvgRating(APIView):
    """
    Avergae Review Rating Get API
        Usage: Get Average Rating of the API by shop
        Authentication Required : YES
        params : {
            "shop" : 1,
        }
        Response : {
            "success" : True,
            "avg_rating" : 3.5,
        }
    """

    permission_classes = (IsAuthenticated,IsNotBanned | IsShopOwner)
    serializer_class = ReviewSerializer

    def get(self,request):
        try:
            reviews =   Review.objects.filter(shop=self.request.GET.get("shop"))
            avg_reviews = 0
            count = 0
            for rv in reviews:
                avg_reviews = avg_reviews + rv.rating
                count = count + 1
            if count == 0:
                return Response({"success" : True, "avg_rating" : 0},status=HTTP_200_OK)
            avg_rt = avg_reviews/count
            return Response(
                {"success":True,"avg_rating" : avg_rt},status=HTTP_200_OK
            )
        except Exception as e:
            return Response(
                {"success": False,"message" : str(e)},status=HTTP_406_NOT_ACCEPTABLE
            )


class ReviewDeletion(DestroyAPIView):
    """
    Review Deletion DELETE API

        Service Usage and Description : This API is used to delete review.
        Authentication Required : YES

        Data : {
            "id" : "1"
        }

        Response : {
            "success" : True,
            "message" : "Review Deleted."
        }
    """

    permission_classes = (IsAuthenticated, IsNotBanned)
    serializer_class = ReviewSerializer

    def get_queryset(self):
        queryset = Review.objects.filter(id=self.request.data["id"])
        return queryset

    def delete(self, request):
        try:
            review = self.get_queryset()
            if review.count() == 0:
                raise Exception("No Review with given id.")
            shopUpdate(
                rating=review[0].rating,
                prev_rating=0,
                opType="Delete",
                shopId=review[0].shop.id,
            )
            self.perform_destroy(review)
            return Response(
                {"success": True, "message": "Review Deleted."},
                status=HTTP_200_OK,
            )
        except Exception as e:
            return Response(
                {"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
            )


class ReviewCommentCreation(CreateAPIView):
    """
    Review Comment Creation POST API

        Service Usage and Description : This API is used to create review comment.
        Authentication Required : YES

        Data : {
            "user"  : "1" (This is the auth_user id, the field in enduser and shopowner, not the enduser id).
            "review" : "1",
            "content" : "asdfghjk"
        }

        Response : {
            "data" : final_data
        }
    """

    permission_classes = (IsAuthenticated, IsShopOwner | IsNotBanned)
    serializer_class = ReviewCommentSerializer


class AllReviewCommentListing(ListAPIView):
    """
    All Review Comment Listing GET API

        Service Usage and Description : This API is used to list all review comments.
        Authentication Required : YES

        Params : {
            "review" : "1"
        }

        Response : {
            "data" : final_data
        }
    """

    permission_classes = (IsAuthenticated, IsNotBanned | IsShopOwner)
    serializer_class = ReviewCommentSerializer

    def get_queryset(self):
        queryset = ReviewComment.objects.filter(review=self.request.GET.get("review"))
        return queryset


    def get(self, request):
        try:
            queryset = self.get_queryset()
            final_data = []
            for reviewComment in queryset:
                temp = {}
                temp["id"] = reviewComment.id
                temp["content"] = reviewComment.content
                temp["created_at"] = reviewComment.created_at
                temp["updated_at"] = reviewComment.updated_at
                enduser = EndUser.objects.filter(auth_user=reviewComment.user)
                if enduser.count():
                    temp["enduser"] = {}
                    temp["enduser"]["id"] = enduser[0].id
                    temp["enduser"]["name"] = enduser[0].name
                    temp["enduser"]["username"] = enduser[0].auth_user.username
                    temp["enduser"]["avatar"] = enduser[0].avatar
                    temp["is_shopowner"] = False
                shopowner = ShopOwner.objects.filter(auth_user=reviewComment.user)
                if shopowner.count():
                    temp["shopowner"] = {}
                    temp["shopowner"]["id"] = shopowner[0].id
                    temp["shopowner"]["name"] = shopowner[0].name
                    temp["shopowner"]["username"] = shopowner[0].auth_user.username
                    temp["shopowner"]["avatar"] = None
                    if shopowner[0].photo:
                        temp["shopowner"]["avatar"] = shopowner[0].photo
                    temp["is_shopowner"] = True
                final_data.append(temp)
            return Response(final_data, status=HTTP_200_OK)
        except Exception as e:
            return Response(
                {"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
            )




class ReviewCommentUpdation(UpdateAPIView):
    """
    Review Comment Updation PUT API

        Service Usage and Description : This API is used to update review comment.
        Authentication Required : YES

        Data : {
            "id" : "1",
            "content": "ABC"
        }

        Response : {
            "success": True,
            "message": "Review Comment Updated."
        }
    """

    permission_classes = (IsAuthenticated, IsShopOwner)
    serializer_class = ReviewCommentSerializer

    def put(self, request):
        try:
            data = request.data
            reviewComment = ReviewComment.objects.filter(id=data["id"])
            if reviewcomment.count() == 0:
                raise Exception("No Review Comment with given id.")
            serializer = ReviewCommentSerializer(
                reviewComment[0], data=data, partial=True
            )
            if serializer.is_valid(raise_exception=True):
                serializer.save()
                return Response(
                    {"success": True, "message": "Review Comment Updated."},
                    status=HTTP_200_OK,
                )
        except Exception as e:
            return Response(
                {"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
            )


class ReviewCommentDeletion(DestroyAPIView):
    """
    Review Comment Deletion DELETE API

        Service Usage and Description : This API is used to delete review comment.
        Authentication Required : YES

        Data : {
            "id" : "1"
        }

        Response : {
            "success" : True,
            "message" : "Review Comment Deleted."
        }
    """

    permission_classes = (IsAuthenticated, IsShopOwner)
    serializer_class = ReviewCommentSerializer

    def get_queryset(self):
        queryset = ReviewComment.objects.filter(id=self.request.data["id"])
        return queryset

    def delete(self, request):
        try:
            reviewComment = self.get_queryset()
            if reviewComment.count() == 0:
                raise Exception("No Review Comment with given id.")
            self.perform_destroy(reviewComment)
            return Response(
                {"success": True, "message": "Review Comment Deleted."},
                status=HTTP_200_OK,
            )
        except Exception as e:
            return Response(
                {"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
            )


class ReviewLikeCreation(CreateAPIView):
    """
    Review Like Creation POST API

        Service Usage and Description : This API is used to create review like.
        Authentication Required : YES

        Data : {
            "review" : "1",
            "enduser" : "1"
        }

        Response : {
            "data" : final_data
        }
    """

    permission_classes = (IsAuthenticated, IsNotBanned)
    serializer_class = ReviewLikeSerializer


class ReviewLikeListing(ListAPIView):
    """
    All Review Like Listing GET API

        Service Usage and Description : This API is used to list review like by an end user.
        Authentication Required : YES

        Params : {
            "review" : "1",
            "enduser" : "1"
        }

        Response : {
            "data" : final_data
        }
    """

    permission_classes = (IsAuthenticated, IsShopOwner)
    serializer_class = ReviewLikeSerializer

    def get_queryset(self):
        queryset = ReviewLike.objects.filter(
            review=self.request.GET.get("review"),
            enduser=self.request.GET.get("enduser"),
        )
        return queryset


class ReviewLikeCountListing(ListAPIView):
    """
    Review Like Count Listing GET API

        Service Usage and Description : This API is used to count all likes for a review.
        Authentication Required : YES

        Params : {
            "review"    :   "1"
        }

        Response : {
            "success" : true,
            "count" : 1
        }
    """

    permission_classes = (IsAuthenticated, IsNotBanned | IsShopOwner)
    serializer_class = ReviewLikeSerializer

    def get(self, request):
        try:
            reviewLikes = ReviewLike.objects.filter(
                review=self.request.GET.get("review")
            )
            return Response(
                {"success": True, "count": reviewLikes.count()}, status=HTTP_200_OK
            )
        except Exception as e:
            return Response(
                {"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
            )


class ReviewLikeDeletion(DestroyAPIView):
    """
    Review Like Deletion DELETE API

        Service Usage and Description : This API is used to delete review like.
        Authentication Required : YES

        Data : {
            "id" : "1"
        }

        Response : {
            "success" : True,
            "message" : "Review Like Deleted."
        }
    """

    permission_classes = (IsAuthenticated, IsNotBanned)
    serializer_class = ReviewLikeSerializer

    def get_queryset(self):
        queryset = ReviewLike.objects.filter(id=self.request.data["id"])
        return queryset

    def delete(self, request):
        try:
            reviewLike = self.get_queryset()
            if reviewLike.count() == 0:
                raise Exception("No Review Like with given id.")
            self.perform_destroy(reviewLike)
            return Response(
                {"success": True, "message": "Review Like Deleted."},
                status=HTTP_200_OK,
            )
        except Exception as e:
            return Response(
                {"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
            )


class ReviewDeletionRequestCreation(APIView):
    """
    Review Deletion Request Creation POST API

        Service Usage and Description : This API is used to create a review deletion request.
        Authentication Required : YES

        Data : {
            "review" : 1,
            "reason" : "Offensive"
        }

        Response : {
            final_data(list of json)
        }
    """

    permission_classes = (IsAuthenticated, IsShopOwner | IsNotBanned | IsSuperAdmin)
    
    def post(self,request):
        try:
            data = json.loads(request.body)
            review = Review.objects.filter(id=data['review'])
            if review.count() == 0:
                raise Exception("No Review With Given ID")
            review = review.first()
            if review.is_report == False:
                reason = {}
                reason['review'] = data['review']
                reason['reason'] = data['reason']
                review.is_report = True
                review.remark = "Requested for deletion"
                serializer = ReviewDeletionRequestSerializer(data=reason)
                if serializer.is_valid(raise_exception=True):
                    serializer.save()
                    review.save()
                    return Response({"success":True,"message":"The review has been reported"})
            else:
                return Response({"success":True,"message":"Already Reported."})        
        
        except Exception as e:
            return Response(
                {"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
            )


class ActiveReviewDeletionRequestListing(ListAPIView):
    """
    Review Delete Reason List Get API

        Params:  {
            "page_no": 1,
            "page_size": 10,
        }
        Service usage and description : This API is used to list review deletion requests.
        Authentication Required : YES
    """

    permission_classes = (
        IsAuthenticated, IsSuperAdmin
    )
    serializer_class = ReviewDeletionRequestSerializer
    queryset = ReviewDeletionRequest.objects.all()

    def get(self, request):
        try:
            p_no= self.request.GET.get("page_no")
            p_size = self.request.GET.get("page_size")
            page_no = 1
            page_size = 10
            review_data = ReviewDeletionRequest.objects.filter(active_status=True)
            if p_no != None:
                page_no = int(self.request.GET.get("page_no"))
            if p_size != None:
                page_size = int(self.request.GET.get("page_size"))
            try:
                if page_size > 200:
                    page_size = 200
                pages = Paginator(review_data, page_size)
                review_d_data = pages.page(page_no)
            except PageNotAnInteger:
                page_no = 1
                review_d_data = pages.page(page_no)
            except EmptyPage:
                page_no = pages.num_pages
                review_d_data = pages.page(page_no)
            page_count = pages.count
            page_info = {
                "page_no": page_no,
                "page_size": page_size,
                "total_topics": page_count,
                "total_pages" : pages.num_pages
            }
            final_data = []
            for index in range(len(review_d_data.object_list)):
                p_list ={}
                p_list['id'] = review_d_data[index].id
                p_list['Review ID'] = review_d_data[index].review.id
                p_list['reason'] =  review_d_data[index].reason
                final_data.append(p_list)
            return Response(
                {"success": True, 
                "data": final_data,
                "page": page_info}, status=HTTP_200_OK
            )
        except Exception as e:
            return Response(
                {"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
            )


class AllReviewDeletionRequestListing(ListAPIView):
    """
    All Review Deletion Request Listing GET API

        Service Usage and Description : This API is used to list all review deletion requests.
        Authentication Required : YES

        Params : {
            "shop" : "1"
        }

        Response : {
            final_data(list of json)
        }
    """

    permission_classes = (IsAuthenticated, IsShopOwner)
    serializer_class = ReviewDeletionRequestSerializer

    def get_queryset(self):
        queryset = ReviewDeletionRequest.objects.filter(
            review__shop_id=self.request.GET.get("shop")
        )
        return queryset


class ReviewDeletionRequestDeletion(APIView):
    """
    Review Delete Requested By ShopOwner API 

        Usage: THis API is used by SuperAdmin to delete the Review requested by shopowner.

        body: {
            "approved" : true,
        }
        response: {
            "success":true,
            "message": "Review Deleted"
        }
    """

    permission_classes = (
        IsAuthenticated, IsSuperAdmin
    )

    def get_object(self, pk):
        try:
            return ReviewDeletionRequest.objects.get(pk=pk)
        except ReviewDeletionRequest.DoesNotExist:
            raise Http404

    def delete(self, request, pk, format=None):
        try:
            review_reason = self.get_object(pk)
            data = json.loads(request.body)
            if data['approved'] == True:
                review = Review.objects.filter(id =review_reason.review.id)
                reason_review = ReviewDeletionRequest.objects.filter(id = review_reason.id)
                if review.count() == 0:
                    raise Exception("No Review with given id.")
                review = review.first()
                reason_review  = reason_review .first()
                review.is_report = False
                review.remark = "Deleted by SuperAdmin"
                review.active_status = False
                reason_review.active_status = False
                reason_review.save()
                review.save()
                return Response({"success":True,"message":"The review has been Deleted"})
            else:
                return Response({"success":True,"message":"Not Approved"})

        except Exception as e:
            return Response(
                {"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
            )


class ReviewDetail(ListAPIView):
    """
    Review Detail get API

        Service Usage and Description : This API is used to review detail.
        Authentication Required : YES
        params: {
            "id" : 1,
        }
        response: {
            "success":true,

        }

    """


    permission_classes = (IsAuthenticated,)
    def get_queryset(self):
        review_id = self.request.GET.get("id")
        queryset = Review.objects.filter()
        if review_id != None:
            queryset = queryset.filter(id=review_id).order_by('-id')
        return queryset


    def get(self, request):
        try:
            final_result = []
            user = request.user
            enduser = EndUser.objects.filter(auth_user=user)
            enduser_id = None
            if enduser.count():
                enduser_id = enduser[0].id
            review_data = self.filter_queryset(self.get_queryset())
            if review_data.count() > 0:
                temp = {}
                temp['id'] = review_data[0].id
                temp["enduser"] = {}
                temp["enduser"]["id"] = review_data[0].enduser.id
                if review_data[0].enduser.id == enduser_id:
                    fcount = Follow.objects.filter(followee=review_data[0].enduser.id)
                    temp["enduser"]["follower_count"] = fcount.count()
                else:
                    fcount = Follow.objects.filter(followee=review_data[0].enduser.id)
                    temp["enduser"]["follower_count"] = fcount.count()
                    followExist = Follow.objects.filter(followee=review_data[0].enduser.id, follower=enduser_id)
                    temp["enduser"]["is_followed"] = False
                    if followExist.count():
                        temp["enduser"]["is_followed"] = True
                        temp["enduser"]["follow_id"] = followExist[0].id
                
                temp["is_liked"] = False
                likeExist = ReviewLike.objects.filter(
                    review=review_data[0].id, enduser__id=enduser_id
                )
                if likeExist.count():
                    temp["is_liked"] = True
                    temp["like_id"] = likeExist[0].id
             
                temp["enduser"]["name"] = review_data[0].enduser.name
                temp["enduser"]["username"] = review_data[0].enduser.auth_user.username
                temp["enduser"]["avatar"] = review_data[0].enduser.avatar
                temp['shop']              = review_data[0].shop.name
                temp['rating']            = review_data[0].rating
                temp['content']           = review_data[0].content
                temp['is_pinned_by_user'] = review_data[0].is_pinned_by_user
                temp['content']           = review_data[0].content
                temp['is_pinned_by_shop'] = review_data[0].is_pinned_by_shop
                temp['views_count']       = review_data[0].views_count
                temp['created_at']        = review_data[0].created_at.strftime("%Y/%m/%d %I:%M %p")
                temp['remark']            = review_data[0].remark
                temp['is_report']         = review_data[0].is_report
                temp['remark']            = review_data[0].remark
                temp['review_like']       = ReviewLike.objects.filter(review_id=review_data[0].id).count()
                temp['review_favourite']  = FavoriteReview.objects.filter(review_id=review_data[0].id).count()
                temp['review_view']       = ReviewViews.objects.filter(review_id=review_data[0].id).count()
                temp['comment_count']     = ReviewComment.objects.filter(review=temp['id']).count()

                temp["is_favorite"] = False
                favoriteExist = FavoriteReview.objects.filter(
                    review_id=review_data[0].id, enduser__id=enduser_id
                )
                if favoriteExist.count():
                    temp["is_favorite"] = True
                    temp["favorite_id"] = favoriteExist[0].id
                    fav_count = FavoriteReview.objects.filter(review_id=review_data[0].id)
                    temp["favorite_count"] = fav_count.count()
                else:
                     temp["favorite_count"] = 0

                final_result.append(temp)
            return Response(
                    {"success": True, 
                    "data": final_result},
                    status=HTTP_200_OK,
                )

        except Exception as e:
            return Response(
                {"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
            )
