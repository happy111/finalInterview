from rest_framework import serializers
from .models import *
from shops.models import Shop
from shops.serializers import ShopSerializer, ShopNameSerializer
from users.serializers import EndUserNameSerializer
from datetime import datetime, timedelta

def shopUpdate(rating, shopId, prev_rating, opType):
    shop = Shop.objects.filter(id=shopId).first()
    data = {}
    if opType == "Delete":
        total = shop.user_rating * shop.review_count
        total = total - rating
        new_rating = total / (shop.review_count - 1)
        data["user_rating"] = new_rating
        data["review_count"] = shop.review_count - 1
    if opType == "Update":
        total = shop.user_rating * shop.review_count
        total = total - prev_rating
        total = total + rating
        new_rating = total / shop.review_count
        data["user_rating"] = new_rating
        data["review_count"] = shop.review_count
    if opType == "Create":
        total = 0
        count = 0
        print(shop.review_count)
        if shop.review_count != None:
            total = shop.user_rating * shop.review_count
            count = shop.review_count
        total = total + rating
        new_rating = total / (count + 1)
        data["user_rating"] = new_rating
        data["review_count"] = count + 1
    serializer = ShopSerializer(shop, data=data, partial=True)
    if serializer.is_valid(raise_exception=True):
        serializer.save()
    return


class ReviewSerializer(serializers.ModelSerializer):
    class Meta:
        model = Review
        fields = "__all__"

    def create(self, validated_data):
        shopUpdate(
            rating=validated_data["rating"],
            shopId=validated_data["shop"].id,
            prev_rating=0,
            opType="Create",
        )
        obj = Review.objects.create(**validated_data)
        return obj

class ReviewDataSerializer(serializers.ModelSerializer):
    shop = ShopNameSerializer()
    enduser = EndUserNameSerializer()
    class Meta:
        model = Review
        fields = "__all__"
    def to_representation(self, instance):
        representation = super(ReviewDataSerializer, self).to_representation(instance)
        created_at = instance.created_at+timedelta(hours=5,minutes=30)
        representation['created_at'] = created_at.strftime("%Y/%m/%d")
        return representation



class ReviewCommentSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReviewComment
        fields = "__all__"


class ReviewLikeSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReviewLike
        fields = "__all__"


class ReviewDeletionRequestSerializer(serializers.ModelSerializer):
    class Meta:
        model = ReviewDeletionRequest
        fields = "__all__"
