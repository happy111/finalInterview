from django.db import models
from django.core.validators import MaxValueValidator, MinValueValidator
from users.models import EndUser
from shops.models import Shop
from django.contrib.postgres.fields import ArrayField
from django.contrib.auth.models import User

class Review(models.Model):
    enduser = models.ForeignKey(
        EndUser,
        related_name="review_enduser",
        null=True,
        on_delete=models.SET_NULL,
        verbose_name="Review Posted By ",
    )
    shop = models.ForeignKey(
        Shop,
        related_name="review_shop",
        on_delete=models.CASCADE,
        verbose_name="Review Shop",
    )
    rating = models.IntegerField(
        default=0.0,
        validators=[MinValueValidator(0), MaxValueValidator(5)],
        verbose_name="Review Shop Rating",
    )
    content = models.CharField(
        max_length=200, null=True, blank=True, verbose_name="Review Content"
    )
    is_pinned_by_user = models.BooleanField(
        default=0, null=True, blank=True, verbose_name="Is Review Pinned By User"
    )
    is_pinned_by_shop = models.BooleanField(
        default=0, null=True, blank=True, verbose_name="Is Review Pinned By Shop"
    )
    is_hidden = models.BooleanField(
        default=0, null=True, blank=True, verbose_name="Is Review Hidden"
    )
    is_active = models.BooleanField(
        default=1, null=True, blank=True, verbose_name="Is Active"
    )
    is_report = models.BooleanField(
        default=0, null=True, blank=True, verbose_name="Is Reported"
    )
    views_count = models.PositiveIntegerField(
        default=0, null=True, blank=True, verbose_name="View Count"
    )
    hashtags = ArrayField(
        models.TextField(),
        null=True, 
        blank=True,\
        verbose_name="Hashtags")
    remark = models.CharField(
        max_length=100, 
        verbose_name="Remark",
        null=True,
        blank=True,
        )
    created_at = models.DateTimeField(
        auto_now_add=True,
        editable=False,
        null=True,
        blank=True,
        verbose_name="Creation Date & Time",
    )
    updated_at = models.DateTimeField(
        auto_now=True, null=True, blank=True, verbose_name="Updation Date & Time"
    )
    expiry_date = models.DateTimeField(
        null=True, blank=True, verbose_name="Expire Date"
    )

    class Meta:
        verbose_name = "Review"
        verbose_name_plural = "Reviews"

    def __str__(self):
        return str(self.shop.name + ", " + self.enduser.name)


class ReviewComment(models.Model):
    user = models.ForeignKey(
        User,
        related_name="reviewcomment_user",
        on_delete=models.CASCADE,
        verbose_name="Review Comment Posted By",
    )

    review = models.ForeignKey(
        Review,
        related_name="reviewcomment_review",
        on_delete=models.CASCADE,
        verbose_name="Review",
    )
    content = models.CharField(max_length=200, verbose_name="Review Content")
    created_at = models.DateTimeField(
        auto_now_add=True,
        editable=False,
        null=True,
        blank=True,
        verbose_name="Creation Date & Time",
    )
    updated_at = models.DateTimeField(
        auto_now=True, null=True, blank=True, verbose_name="Updation Date & Time"
    )

    class Meta:
        verbose_name = "Review Comment"
        verbose_name_plural = "Review Comments"

    def __str__(self):
        return self.review.shop.name + ", " + self.review.enduser.name


class ReviewLike(models.Model):
    review = models.ForeignKey(
        Review,
        related_name="reviewlike_review",
        on_delete=models.CASCADE,
        verbose_name="Review",
    )
    enduser = models.ForeignKey(
        EndUser,
        related_name="reviewlike_enduser",
        on_delete=models.CASCADE,
        verbose_name="Review Liked By",
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        editable=False,
        null=True,
        blank=True,
        verbose_name="Creation Date & Time",
    )

    class Meta:
        verbose_name = "Review Like"
        verbose_name_plural = "Review Likes"


class ReviewDeletionRequest(models.Model):
    review = models.ForeignKey(
        Review,
        related_name="reviewdeletionrequest_review",
        on_delete=models.CASCADE,
        verbose_name="Review",
    )
    reason = models.CharField(
        max_length=250, null=True, blank=True, verbose_name="Reason"
    )
    active_status = models.BooleanField(
        default=True, null=True, blank=True, verbose_name="Request Active Status"
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        editable=False,
        null=True,
        blank=True,
        verbose_name="Creation Date & Time",
    )

    class Meta:
        verbose_name = "Review Deletion Request"
        verbose_name_plural = "Review Deletion Requests"

    def __str__(self):
        return self.review.shop.name + ", " + self.review.enduser.name
