from django.urls import path
from .views import *



urlpatterns = [
    path("create/", ReviewCreation.as_view()),
    path("active-listing/", ActiveReviewListing.as_view()),
    path("all-listing/", AllReviewListing.as_view()),
    path("count-listing/", ReviewCountListing.as_view()),
    path("update/", ReviewUpdation.as_view()),
    path("delete/", ReviewDeletion.as_view()),
    path("comment-create/", ReviewCommentCreation.as_view()),
    path("comment-listing/", AllReviewCommentListing.as_view()),
    path("comment-update/", ReviewCommentUpdation.as_view()),
    path("comment-delete/", ReviewCommentDeletion.as_view()),
    path("like-create/", ReviewLikeCreation.as_view()),
    path("like-listing/", ReviewLikeListing.as_view()),
    path("like-count-listing/", ReviewLikeCountListing.as_view()),
    path("like-delete/", ReviewLikeDeletion.as_view()),
    path("deletion-request-create/", ReviewDeletionRequestCreation.as_view()),
    path(
        "deletion-request-active-listing/", ActiveReviewDeletionRequestListing.as_view()
    ),
    path("deletion-request-all-listing/", AllReviewDeletionRequestListing.as_view()),
    path("deletion-request-delete/<pk>/", ReviewDeletionRequestDeletion.as_view()),
    path("count-hidden-deleted-listing/",ReviewDeleteHiddenCountList.as_view()),
    path("average-rating/",ReveiwAvgRating.as_view()), 
    path("reviewdetail/", ReviewDetail.as_view()),

]