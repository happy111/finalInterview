from django.urls import path
from .views import *

urlpatterns = [

    path("active-listing/", ActiveShopListing.as_view()),
    path("update/", ShopUpdation.as_view()),
    path("data-listing/", ShopDataListing.as_view()),
    path("faq-create/", FAQCreation.as_view()),
    path("faq-listing/", FAQListing.as_view()),
    path("faq-update/", FAQUpdation.as_view()),
    path("faq-delete/", FAQDeletion.as_view()),
    path("create/", ShopCreation.as_view()),
    path("alllist/",ShopAllListAPI.as_view())
    
]
