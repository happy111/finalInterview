from rest_framework import serializers
from .models import *


class ShopSerializer(serializers.ModelSerializer):
    class Meta:
        model = Shop
        fields = "__all__"


class FAQSerializer(serializers.ModelSerializer):
    class Meta:
        model = FAQ
        fields = "__all__"

class ShopNameSerializer(serializers.ModelSerializer):
    class Meta:
        model = Shop
        fields = ("id", "name", "profile_photo")