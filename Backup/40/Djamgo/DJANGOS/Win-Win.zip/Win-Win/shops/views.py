from .models import *
from .serializers import ShopSerializer, FAQSerializer
from rest_framework.generics import (
    CreateAPIView,
    ListAPIView,
    DestroyAPIView,
    UpdateAPIView,
)
from rest_framework.permissions import IsAuthenticated

# from userrole.permissions import IsSuperAdmin, IsAdmin
from winwin.permissions import IsShopOwner, IsNotBanned , IsSuperAdmin
from rest_framework.response import Response
from rest_framework.status import HTTP_200_OK, HTTP_406_NOT_ACCEPTABLE
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from area.models import *


class ShopDataListing(ListAPIView):
    """
    Shop Data Listing GET API

        Service Usage and Description : This API is used to list the data for a shop using id.
        Authentication Required : YES

        Params  :   {
            "shop" : 1
        }

        Response : {
            final_data(list of json)
        }
    """

    permission_classes = (IsAuthenticated, IsShopOwner | IsNotBanned)
    serializer_class = ShopSerializer

    def get_queryset(self):
        queryset = Shop.objects.filter(id=self.request.GET.get("shop"))
        return queryset

    def get(self, request):
        try:
            queryset = self.filter_queryset(self.get_queryset())
            if queryset.count() == 0:
                raise Exception("No Shop for the id.")
            final_data = []
            from users.models import EndUser
            user = request.user
            enduser = EndUser.objects.filter(auth_user=user)
            enduser_id = None
            if enduser.count():
                enduser_id = enduser[0].id
            for shop in queryset:
                temp = {}
                temp["id"] = shop.id
                temp["genre"] = shop.genre.name
                temp["city"] = shop.city.name
                temp["address"] = shop.address
                temp["profile_photo"] = None
                temp["name"] = shop.name
                temp["banner"] = None
                try:
                    temp["profile_photo"] = (request.build_absolute_uri()).replace(
                        request.get_full_path(), ""
                    ) + shop.profile_photo.url
                except Exception as e:
                    print(str(e))
                try:
                    temp["banner"] = (request.build_absolute_uri()).replace(
                        request.get_full_path(), ""
                    ) + shop.banner.url
                except Exception as e:
                    print(str(e))
                temp["opening_time"] = shop.opening_time
                temp["closing_time"] = shop.closing_time
                temp["is_24hr_open"] = shop.is_24hr_open
                temp["phone_number"] = str(shop.phone_number)
                temp["staff_attitude_rating"] = shop.staff_attitude_rating
                temp["pay_rating"] = shop.pay_rating
                temp["user_rating"] = shop.user_rating
                temp["views_count"] = shop.views_count
                temp["is_premium"] = shop.is_premium
                temp["is_banned"] = shop.is_banned
                temp["is_favorite"] = False
                from socialfeatures.models import FavoriteShop
                favoriteExist = FavoriteShop.objects.filter(
                    shop=shop, enduser__id=enduser_id
                )
                if favoriteExist.count():
                    temp["is_favorite"] = True
                    temp["favorite_id"] = favoriteExist[0].id
                temp["active_status"] = shop.active_status
                final_data.append(temp)
            return Response(final_data, status=HTTP_200_OK)
        except Exception as e:
            return Response(
                {"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
            )


class ActiveShopListing(ListAPIView):
    """
    Active Shop Listing GET API

        Service Usage and Description : This API is used to list active Shops.
        Authentication Required : YES

        Params : {
            "city" : 1 (optional)
            "genre" : 1 (optional)
        }

        Response : {
            "data" : final_data
        }
    """

    permission_classes = (IsAuthenticated, IsShopOwner | IsNotBanned)
    serializer_class = ShopSerializer

    def get_queryset(self):
        queryset = Shop.objects.filter(active_status=True, is_banned=False)
        data = {}
        data["city"] = self.request.GET.get("city")
        data["genre"] = self.request.GET.get("genre")
        if data["city"] != None:
            queryset = queryset.filter(city=data["city"])
        if data["genre"] != None:
            queryset = queryset.filter(genre=data["genre"])
        return queryset


class ShopUpdation(UpdateAPIView):
    """
    Shop Updation PUT API

        Service Usage and Description : This API is used to update Shop.
        Authentication Required : YES

        Data : {
            "id" : "1",
            "name": "ABC"
        }

        Response : {
            "success": True,
            "message": "Shop Updated."
        }
    """

    permission_classes = (IsAuthenticated,)
    serializer_class = ShopSerializer

    def put(self, request):
        try:
            data = request.data
            shop = Shop.objects.filter(id=data["id"])
            if shop.count() == 0:
                raise Exception("No Shop with given id.")
            serializer = ShopSerializer(shop[0], data=data, partial=True)
            if serializer.is_valid(raise_exception=True):
                serializer.save()
                return Response(
                    {"success": True, "message": "Shop Updated."},
                    status=HTTP_200_OK,
                )
        except Exception as e:
            return Response(
                {"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
            )




class FAQCreation(CreateAPIView):
    """
    FAQ Creation POST API

        Service Usage and Description : This API is used to create FAQ.
        Authentication Required : YES

        Data : {
            "shop" : shop_id,
            "question" : "Question",
            "answer" : "answer"
        }

        Response : {
            "data" : final_data
        }
    """

    permission_classes = (IsAuthenticated, IsShopOwner)
    serializer_class = FAQSerializer


class FAQListing(ListAPIView):
    """
    FAQ Listing GET API

        Service Usage and Description : This API is used to list FAQ for a shop.
        Authentication Required : YES

        Params : {
            "shop" : 1
        }

        Response : {
            "data" : final_data
        }
    """

    permission_classes = (IsAuthenticated, IsNotBanned | IsShopOwner)
    serializer_class = FAQSerializer

    def get_queryset(self):
        queryset = FAQ.objects.filter(shop=self.request.GET.get("shop"))
        return queryset


class FAQUpdation(UpdateAPIView):
    """
    FAQ Updation PUT API

        Service Usage and Description : This API is used to update FAQ.
        Authentication Required : YES

        Data : {
            "id" : "1",
            "answer": "ABC"
        }

        Response : {
            "success": True,
            "message": "FAQ Updated."
        }
    """

    permission_classes = (IsAuthenticated, IsShopOwner)
    serializer_class = FAQSerializer

    def put(self, request):
        try:
            data = request.data
            faq = FAQ.objects.filter(id=data["id"])
            if faq.count() == 0:
                raise Exception("No FAQ with given id.")
            serializer = FAQSerializer(faq[0], data=data, partial=True)
            if serializer.is_valid(raise_exception=True):
                serializer.save()
                return Response(
                    {"success": True, "message": "FAQ Updated."},
                    status=HTTP_200_OK,
                )
        except Exception as e:
            return Response(
                {"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
            )


class FAQDeletion(DestroyAPIView):
    """if data["city"] != None:
            queryset = queryset.filter(city=data["city"])

        Service Usage and Description : This API is used to delete FAQ.
        Authentication Required : YES

        Data : {
            "id" : "1"
        }

        Response : {
            "success": True,
            "message": "FAQ Deleted."
        }
    """

    permission_classes = (IsAuthenticated, IsShopOwner)
    serializer_class = FAQSerializer

    def get_queryset(self):
        faq_id = self.request.data["id"]
        queryset = FAQ.objects.filter(id=faq_id)
        return queryset

    def delete(self, request):
        try:
            faq = self.get_queryset()
            if faq.count() == 0:
                raise Exception("No FAQ with given id.")
            self.perform_destroy(faq)
            return Response(
                {"success": True, "message": "FAQ Deleted."},
                status=HTTP_200_OK,
            )
        except Exception as e:
            return Response(
                {"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
            )



class ShopCreation(CreateAPIView):
    """
    Shop Creation Post API

        Service Usage and Description : This API is used to create shop.
        Authentication Required : YES

        Data : {
            "genre"          : "1",  (pk)
            "name"           : "ABC"
            "city"           : ""    (pk)
            "address"        : ""
            "profile_photo"  :   ""
            "banner"         :"banner.jpg"
            "bio"            : ""
            "opening_time"   : "08:25:00"
            "closing_time"   : "18:25:00"
            "phone_number"   : "+918750477098"
            "is_24hr_open"   : boolen field
        }

        Response : {
            "success": True,
            "message": "Review Comment Updated."
        }
    """


    permission_classes = (IsAuthenticated,)
    serializer_class = ShopSerializer
    queryset = Shop.objects.all()

class ShopAllListAPI(ListAPIView):
    """
    Shop List Get API

        Service usage and description : This API is used to list shops.
        Authentication Required : YES

        Params:  {
            "page_no": 1,
            "page_size": 10,
            "city" : 1,
            "area" : 1,
            "state" : 1,
        }
    """

    permission_classes = (
        IsAuthenticated, IsSuperAdmin
    )
    serializer_class = ShopSerializer
    queryset = Shop.objects.all()

    def get(self, request):
        try:
            area = self.request.GET.get("area")
            state = self.request.GET.get("state")
            city = self.request.GET.get("city")
            p_no= self.request.GET.get("page_no")
            p_size = self.request.GET.get("page_size")
            page_no = 1
            page_size = 10
            data = {}
            data["area"] = self.request.GET.get("area")
            data["city"] = self.request.GET.get("city")
            if data["city"] != None:
                shop_data = Shop.objects.filter(city=data["city"])
            if area != None and state == None and city == None:
                alldata = Shop.objects.filter()
                city_id = []
                for index in alldata:
                    if index.city.state.area_id == int(area):
                        city_id.append(index.city_id)
                city_set = list(set(city_id))
                shop_data = Shop.objects.filter(city__in=city_set)
            
            if state != None and city == None:
                alldata = Shop.objects.filter()
                
                city_id = []
                for index in alldata:
                    if index.city.state_id == int(state):
                        city_id.append(index.city_id)
                city_set = list(set(city_id))
                shop_data = Shop.objects.filter(city__in=city_set)

            if data["city"] == None and area == None and state == None:
                shop_data = Shop.objects.filter()
                
            if p_no != None:
                page_no = int(self.request.GET.get("page_no"))
            if p_size != None:
                page_size = int(self.request.GET.get("page_size"))
            try:
                if page_size > 200:
                    page_size = 200
                pages = Paginator(shop_data, page_size)
                shop_detail_data = pages.page(page_no)
            except PageNotAnInteger:
                page_no = 1
                shop_detail_data = pages.page(page_no)
            except EmptyPage:
                page_no = pages.num_pages
                shop_detail_data = pages.page(page_no)
            page_count = pages.count
            page_info = {
                "page_no": page_no,
                "page_size": page_size,
                "total_topics": page_count,
                "total_pages" : pages.num_pages
            }
            final_data = []
            for index in range(len(shop_detail_data.object_list)):
                p_list ={}
                p_list['id'] = shop_detail_data[index].id
                p_list['shop_name'] = shop_detail_data[index].name
            #    p_list['phone_number'] = shop_detail_data[index].phone_number
                p_list['city'] =  shop_detail_data[index].city.name if shop_detail_data[index].city else ''
                p_list['is_premium'] = shop_detail_data[index].is_premium
                p_list['bio'] = shop_detail_data[index].bio
                p_list['shop_address'] = shop_detail_data[index].address
                p_list['opening_time'] = shop_detail_data[index].opening_time
                p_list['closing_time'] = shop_detail_data[index].closing_time
                p_list['comment'] = shop_detail_data[index].comment
                p_list['genre'] = shop_detail_data[index].genre.id
                p_list['shop_url'] = shop_detail_data[index].url
                p_list['active_status'] = shop_detail_data[index].active_status

                final_data.append(p_list)
            return Response(
                {"success": True, 
                "data": final_data,
                "page": page_info}, status=HTTP_200_OK
            )
        except Exception as e:
            return Response(
                {"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
            )
