from .models import *
from .serializers import NotificationSerializer,NotifySerializer,HashSerializer
from rest_framework.generics import (
	CreateAPIView,
	ListAPIView,
	DestroyAPIView,
	UpdateAPIView,
)
from rest_framework.permissions import IsAuthenticated
from win.permissions import IsShopOwner, IsNotBanned,IsSuperAdmin
from rest_framework.response import Response
from rest_framework.status import HTTP_200_OK, HTTP_406_NOT_ACCEPTABLE
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from rest_framework.views import APIView
from users.models import ShopOwner
from Notification.models import Notify



class NotificationCreation(CreateAPIView):
	"""
	Notification Creation Post API

		Service Usage and Description : This API is used to create notification.
		Authentication Required : YES

		Data : {
			"subject"             : "create shop",  
			"message"             : "Shop is created"

		}

		Response : {
			"success": True,
			"message": "Shop is created"
		}
	"""


	permission_classes = (IsAuthenticated,IsSuperAdmin)
	def post(self, request, format=None):
		try:
			data = request.data
			serializer = NotificationSerializer(data=data)
			if serializer.is_valid(raise_exception=True):
				data_info = serializer.save()
				notify = {}
				notify['notification'] = data_info.id 
				allshop = Shop.objects.filter(active_status=1)
				for index in allshop:
					notify['shop'] = index.id
					notifyserializer = NotifySerializer(data=notify)
					if notifyserializer.is_valid(raise_exception=True):
						data_info = notifyserializer.save()
				return Response(
					{"success": True, 
					"message": 'Notification is created!!'},
					status=HTTP_200_OK,
				)

		except Exception as e:
			return Response(
				{"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
			)



class NotificationList(APIView):
	"""
	Notification List get API

		Service Usage and Description : This API is used to list notification ShopOwner.
		Authentication Required : YES

	"""


	permission_classes = (IsAuthenticated,IsShopOwner)
	def get(self, request, format=None):
		try:
			data = request.data
			shop_id = ShopOwner.objects.filter(auth_user_id=request.user.id)[0].shop_id
			notify_data = Notify.objects.filter(shop_id= shop_id,is_seen=0)
			final_result = []
			if notify_data.count() > 0:
				for index in notify_data:
					temp = {}
					ndata = Notification.objects.filter(id = index.notification_id)
					temp['subject'] = ndata[0].subject
					temp['message'] = ndata[0].message
					temp['id'] = index.id
					final_result.append(temp)
			return Response(
					{"success": True, 
					"data": final_result},
					status=HTTP_200_OK,
				)

		except Exception as e:
			return Response(
				{"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
			)



class NotificationUpdate(UpdateAPIView):
	"""
	Notification Updation PUT API

		Service Usage and Description : This API is used to update notification .
		Authentication Required : YES

		Data : {
			"id" : "1"

		}

		Response : {
			"success": True,

		}
	"""

	permission_classes = (IsAuthenticated,IsShopOwner)
	serializer_class = NotifySerializer
	def put(self, request):
		try:
			data = request.data
			data['is_seen'] = 1
			shop_id = ShopOwner.objects.filter(auth_user_id=request.user.id)[0].shop_id
			notify_data = Notify.objects.filter(id=data["id"],shop_id=shop_id)
			if notify_data.count() == 0:
				raise Exception("No Notification with given id.")
			serializer = NotifySerializer(notify_data[0], data=data, partial=True)
			if serializer.is_valid(raise_exception=True):
				serializer.save()
				return Response(
					{"success": True, "message": "Notification Updated."},
					status=HTTP_200_OK,
				)
		except Exception as e:
			return Response(
				{"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
			)

class NotificationSuperAdminList(ListAPIView):
	"""
	Notification List get API

		Service Usage and Description : This API is used to list notification SuperAdmin.
		Authentication Required : YES

		Params:  {
            "page_no": 1,
            "page_size": 10,
		}
	"""

	permission_classes = (IsAuthenticated,IsSuperAdmin)
	serializer_class = NotificationSerializer
	queryset = Notification.objects.all()

	def get(self, request):
		try:
			p_no= self.request.GET.get("page_no")
			p_size = self.request.GET.get("page_size")
			page_no = 1
			page_size = 10
			data = {}
			notification_data = Notification.objects.filter()
			if p_no != None:
			    page_no = int(self.request.GET.get("page_no"))
			if p_size != None:
			    page_size = int(self.request.GET.get("page_size"))
			try:
				if page_size > 200:
					page_size = 200
				pages = Paginator(notification_data, page_size)
				notification_detail_data = pages.page(page_no)
			except PageNotAnInteger:
				page_no = 1
				notification_detail_data = pages.page(page_no)
			except EmptyPage:
				page_no = pages.num_pages
				notification_detail_data = pages.page(page_no)
			page_count = pages.count
			page_info = {
                "page_no": page_no,
                "page_size": page_size,
                "total_topics": page_count,
                "total_pages" : pages.num_pages
            }
			final_data = []
			for index in range(len(notification_detail_data.object_list)):
				p_list ={}
				p_list['id'] = notification_detail_data[index].id
				p_list['subject'] = notification_detail_data[index].subject
				p_list['message'] = notification_detail_data[index].message
				p_list["created_at"] = notification_detail_data[index].created_at
				final_data.append(p_list)
			return Response(
                {"success": True, 
                "data": final_data,
                "page": page_info}, status=HTTP_200_OK
            )
		except Exception as e:
			return Response(
                {"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
            )

class NotificationDelete(DestroyAPIView):
	"""
    Notification Deletion DELETE API

        Service Usage and Description : This API is used to delete Notification.
        Authentication Required : YES

        Data : {
            "id" : "1"
        }

        Response : {
            "success" : True,
            "message" : "Notification Deleted."
        }
    """
	permission_classes = (IsAuthenticated, IsSuperAdmin)
	serializer_class = NotificationSerializer

	def get_queryset(self):
		queryset = Notification.objects.filter(id=self.request.data["id"])
		return queryset
	
	def delete(self, request):
		try:
			notification = self.get_queryset()
			if notification.count() == 0:
				raise Exception("No Notification with given id.")
			self.perform_destroy(notification)
			return Response(
                {"success": True, "message": "Notification Deleted."},
                status=HTTP_200_OK,
            )
		except Exception as e:
			return Response(
                {"success": False, "message": str(e)}, status=HTTP_406_NOT_ACCEPTABLE
            )


class HashtagList(ListAPIView):
    """
    Hashtag List GET API

        Service usage and description : This API is used to list hashtag.
        Authentication Required : YES

    """

    permission_classes = (
        IsAuthenticated,
    )
    serializer_class = HashSerializer
    queryset = Hashtag.objects.all()
