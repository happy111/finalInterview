from django.urls import path
from .views import *

urlpatterns = [

    path("create/", NotificationCreation.as_view()),
    path("list/",  NotificationList.as_view()),
    path("notification-list/",NotificationSuperAdminList.as_view()),
    path("isseen/",  NotificationUpdate.as_view()),
    path("delete/",NotificationDelete.as_view()),
    path("hashtag/list/",HashtagList.as_view())
]
