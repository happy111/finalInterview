from django.db import models
from shops.models import Shop

class Notification(models.Model):
    subject = models.CharField(
        max_length=100, 
        null=True, 
        blank=True, 
        verbose_name="Subject")
    message = models.CharField(
        max_length=100, 
        verbose_name="Message")
    active_status = models.BooleanField(
        default=1, 
        null=True, 
        blank=True, 
        verbose_name="Notification Active Status"
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        editable=False,
        null=True,
        blank=True,
        verbose_name="Creation Date & Time",
    )
    updated_at = models.DateTimeField(
        auto_now=True, 
        null=True, 
        blank=True, 
        verbose_name="Updation Date & Time"
    )

    class Meta:
        verbose_name = "Notification"
        verbose_name_plural = "Notification"

    def __str__(self):
        return self.message

class Notify(models.Model):
    notification = models.ForeignKey(
        Notification,
        related_name='Notify_notification',
        on_delete=models.CASCADE,
        null=True,
        verbose_name='Notification',
        limit_choices_to={'active_status': '1'})

    shop = models.ForeignKey(
        Shop,
        related_name='Notify_shop',
        on_delete=models.CASCADE,
        null=True,
        verbose_name='Shop',
        limit_choices_to={'active_status': '1'})

    is_seen = models.BooleanField(
        default=0, 
        null=True, 
        blank=True, 
        verbose_name="Notification Active Status"
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        editable=False,
        null=True,
        blank=True,
        verbose_name="Creation Date & Time",
    )
    updated_at = models.DateTimeField(
        auto_now=True, 
        null=True, 
        blank=True, 
        verbose_name="Updation Date & Time"
    )

    class Meta:
        verbose_name = "Notify"
        verbose_name_plural = "Notify"

    def __str__(self):
        return self.notification.message


class Hashtag(models.Model):
    text = models.CharField(
        max_length=100, 
        null=True, 
        blank=True, 
        verbose_name="Name")

    is_active = models.BooleanField(
        default=1, 
        null=True, 
        blank=True, 
        verbose_name="Is Active"
    )

    created_at = models.DateTimeField(
        auto_now_add=True,
        editable=False,
        null=True,
        blank=True,
        verbose_name="Creation Date & Time",
    )
    updated_at = models.DateTimeField(
        auto_now=True, 
        null=True, 
        blank=True, 
        verbose_name="Updation Date & Time"
    )

    class Meta:
        verbose_name = "Hashtag"
        verbose_name_plural = "Hashtag"

    def __str__(self):
        return self.text