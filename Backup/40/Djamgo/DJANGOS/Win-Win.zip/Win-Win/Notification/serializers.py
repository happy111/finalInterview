from rest_framework import serializers
from .models import *


class NotificationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Notification
        fields = "__all__"

class NotifySerializer(serializers.ModelSerializer):
    class Meta:
        model = Notify
        fields = "__all__"

class HashSerializer(serializers.ModelSerializer):
    class Meta:
        model = Hashtag
        fields = ("id", "text")